<html>
<?php

include'paxinas/header.php';
include'datos/datos.php';
$db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
$x='';
$cont;
if($db){
  $consulta2= "SELECT count(id_prod) FROM productos";
  $res2 = mysqli_query($db, $consulta2);
  $cantidad_prod = mysqli_fetch_row($res2);
  mysqli_close($db);
}

if (isset($_GET["paxina"])){
  if(($_GET["paxina"]) >0){
    $pax = $_GET["paxina"];    
  }
}else{
  $pax=1;
}

if (isset($_GET["paxina"])){
  if(($_GET["paxina"]) >1){
    $paxant= --$_GET["paxina"];
    
  }else{
    $paxant=null;
  }
}

$paxsig = $pax + 1;
if (isset($_GET["paxina"])){
  if(($_GET["paxina"]) >0){
    //$pax=$_GET["paxina"];
    $x=($pax-1)*6;
    $cont=($pax-1)*6;
    echo "<aside id='esquerda'>";

    echo "</aside>";

    echo "<section id='main'>"; 
    //REALIZAR CONEXION COA BASE DE DATOS


    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){      
      $consulta = "SELECT id_prod, titulo, prezo, imaxe FROM productos order by id_prod desc LIMIT $x,6";
      $res = mysqli_query($db, $consulta);          
      if($res){
        while($prod = mysqli_fetch_assoc($res)){          
          echo "<a href='paxinas/generarArticulo1.php?art=".$prod['id_prod']."'>";
            echo "<article>";
              echo "<h2>"."<p>".$prod['titulo']."</p>"."</h2>";
              echo "<img class='imagen' src='imaxesproductos/".$prod['imaxe']."'>";
              echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
            echo "</article>";
          echo "</a>";
          $cont++;
        }
        mysqli_close($db);
      }else{
        echo "Non seleccionado";
      }
    }else {
      echo "Error ao conectarme a Base de Datos";
    }
    include'paxinas/flechas.php';
  }
 
}else{
  $cont='';
  echo "<aside id='esquerda'>";
  


  echo "</aside>";
  $paxsig=$pax+1;
  echo "<section id='main'>"; 
  //REALIZAR CONEXION COA BASE DE DATOS

  $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
  if($db){
    $consulta = "SELECT id_prod, titulo, prezo, imaxe FROM productos order by id_prod desc LIMIT 0,6";
    $res = mysqli_query($db, $consulta);          
    if($res){
      while($prod = mysqli_fetch_assoc($res)){          
        echo "<a href='paxinas/generarArticulo1.php?art=".$prod['id_prod']."'>";
        echo "<article>";
          echo "<h2>"."<p>".$prod['titulo']."</p>"."</h2>";
          echo "<img src='imaxesproductos/".$prod['imaxe']."'>";
          echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
        echo "</article>";
        echo "</a>";
        $cont++;
      }
      mysqli_close($db);
    }else{
      echo "Non seleccionado";
    }
  }else {
    echo "Error ao conectarme a Base de Datos";
  }
  include'paxinas/flechas.php';

}

//if(isset($_GET["paxina"])){
//  $paxsig=$_GET["paxina"]+1;
//}

?>

</section>
    <aside id="dereita">

    </aside>

<?php
  include 'paxinas/footer.php';
?>

  </body>
</html>