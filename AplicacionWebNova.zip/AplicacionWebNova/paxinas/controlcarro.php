<?php

session_start();
$email = $_SESSION["miSesion"];


if(isset($_POST["comprar"])){
    $comprar = $_POST["comprar"];
    $id_artigo = $_POST["oculto"];

    if($_SESSION["tipo"] == "admin"){
        header('Location: ../paxinas/soNormais.php');
    }elseif($_SESSION["tipo"] == "normal"){
        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
        if($db){
            $insercion = "INSERT INTO deseados (id_usuario, id_prod) VALUES (".$_SESSION['id_usuario'].", $id_artigo)";
            $res = mysqli_query($db, $insercion);
            print_r($res);
            if($res){
                header('Location: ../paxinas/carro.php?usuario='.$_SESSION['id_usuario'].'');
            }else{
                header('Location: ../paxinas/carro.php?usuario='.$_SESSION['id_usuario'].'');
            }
        }
        
    }
        

}













?>