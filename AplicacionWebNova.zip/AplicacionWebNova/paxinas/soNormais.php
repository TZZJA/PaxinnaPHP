<html>
<?php

include'header2.php';
?>
    <aside id="esquerda">
    </aside>

    <section id='main'>
        <h1>SO OS USUARIOS NORMAIS PODEN COMPRAR</h1>
    </section>

    <aside id="dereita">
      <p>
        
      </p>
    </aside>

<?php
  include 'paxinas/footer.php';
?>

  </body>
</html>