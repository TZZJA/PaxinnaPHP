<html>
    <head>
    <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    <link href='https://fonts.googleapis.com/css2?family=Open+Sans&display=swap' rel='stylesheet'/>
    <link rel='icon' type='image/gif' href='../imaxes/favicon.gif'/>
    </head>
    <body>
    <?php
    session_start();

    if(isset($_POST["devolver_x"])){

        $db =  mysqli_connect("localhost", "root", "", "tenda_hw_boa");
        if($db){
            $actu = "UPDATE pedidos_productos SET estado='Devolto' WHERE id_compra = '".$_POST['idcompra']."' AND id_prod='".$_POST['idproducto']."'";
            mysqli_query($db, $actu);
            mysqli_close($db);
        }
    }   


    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if(!empty($_SESSION)){
        if(!empty($_SESSION)){
            if($db){
                    echo "
                            <section id='main'>
                                <h1>Pedidos realizados</h1>                              
                                <div id='carrito'>";
                                    $consulta2 = "SELECT p.id_compra, pr.prezo, p.fecha_pedido, pr.imaxe, pr.titulo, pepo.estado, pr.id_prod FROM (pedidos p INNER JOIN pedidos_productos pepo ON p.id_compra = pepo.id_compra INNER JOIN productos pr ON pr.id_prod = pepo.id_prod) where p.id_usuario='".$_SESSION['id_usuario']."'";
                                    $res = mysqli_query($db,$consulta2);
                                    
                                    while ($comprar = mysqli_fetch_assoc($res)) {                          
                                        echo"
                                        <div class='carro'>
                                            <div class='art'>
                                                <img id='imgcarro' src='".$comprar['imaxe']."' />
                                            </div>
                                            <div class='art'>".$comprar['titulo']."</div>
                                            <div class='art'><br/>";

                                    echo"       <form method='post' action='pedidos.php'>";
                                                    
                    
                                echo"           
                                                    </div>
                                                    <div class='art'>".$comprar['prezo']."</div>";
                                                    if($comprar['estado'] == 'Enviado'){
                                         echo"          <div class='art'>
                                                            <input type='image' id='imgpapel' src='../imaxes/devolver2.png' name='devolver' /> 
                                                            <input type='hidden' name='idcompra' value='".$comprar['id_compra']."' />
                                                            <input type='hidden' name='idproducto' value='".$comprar['id_prod']."' />                                          
                                                        </div>";
                                                    }
                                                    
                              echo"              </form>";
                                              
                             echo"         </div>";
                                    }      
                    echo "      </div>
                            </section>";
                
            }else{
                mysqli_close($db);
                echo "Mal conectado";
            }
        }elseif(isset($_SESSION["tipo"])) {
            if($_SESSION["tipo"] == "admin"){
                echo "<section id='main'>
                        <h1>Ti non podes comprar</h1>";

                echo "</section>";
            }
        }else{
            echo " <section id='main'>
                    <h1>Logeate para ver tu carrito</h1>";  
            echo " </section>";

        }
    }
?>

    </form>
    </body>
</html>