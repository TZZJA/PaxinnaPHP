<?php

function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}


$id_prod_buscado = valida('id_prod');
$nombre_prod_buscado = valida('nom_prod');

$id_prod_buscadoOK = false;
$nombre_prod_buscadoOK = false;

if($id_prod_buscado == ""){
    echo "<h1>Id do producto vacío</h1>";
}elseif(!is_numeric($id_prod_buscado)){
    echo "<h1>O id do producto ten que ser un número</h1>";
}else{
    $id_prod_buscadoOK = true;
}

if ($nombre_prod_buscado == "") {
    print "  <h1>Non escribiu o nombre</h1>";
    print "\n";
}else {
    $nombre_prod_buscadoOK = true;
}

if($nombre_prod_buscadoOK && $id_prod_buscadoOK){
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $borrado= "DELETE FROM productos WHERE id_prod=".$id_prod_buscado." AND titulo='".$nombre_prod_buscado."'";
        $res = mysqli_query($db, $borrado);
        if($res){
            mysqli_close($db);
            echo "<h1>Borrado!</h1>";
        }else{
            echo "<h1>Non se borrou!</h1>";
            echo $borrado;
            mysqli_close($db);
        }

    }else {
        echo "<h1>mal conectado</h1>";
        mysqli_close($db);
    }
}

echo "<aside id='esquerda'>";
echo "</aside>";
echo "<section id='main'>"; 

?>