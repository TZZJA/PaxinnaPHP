<html>
<head>
  <link href='../css/css.css' rel='stylesheet' type='text/css'/>
</head>
   <body>

      
           <form method="post" action="devol_prod.php" autocomplete="on">
              <div class="ver">
              <label for="fechad">Fecha devolucion: </label><br/>
                <input type="date" id="fechad" name="fecha_dev"/><br/>
                <input type="submit" name="ver" value="Ver lista" />

                <div id="verlista">
                </div>
              </div>

            </form>






  </body>
</html>
