<html>
    <?php
    include'header2.php';
    include'../datos/datos.php';
    ?>
    <aside id="esquerda">
        <ul id="productos">
            <?php
            $array_productos=array();
            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
            if($db){
                $consulta = "SELECT nome_articulo from tipo_articulo";
                $consultaid= "SELECT id_articulo from tipo_articulo";
                $rdo = mysqli_query($db, $consulta);
                $rdo2 = mysqli_query($db, $consultaid);
                if($rdo && $rdo2){
                    while($prod = mysqli_fetch_row($rdo)){
                        $idprod = mysqli_fetch_assoc($rdo2);
                        echo "<li><a href='generarProductos.php?prod=".$idprod['id_articulo']."' target='iframe_a'>".strtoupper($prod[0])."</a></li>";            
                    }

                }else{
                    echo "Consulta mal feita";
                }
            }else{
                echo "Error ao conectarse";
            }
            ?>
        </ul>
    </aside>

    <section id="main">      
       <iframe class="ver" src="generarProductos.php?prod=1" name="iframe_a" style="margin-left: -2%;" height="100%" width="100%" title="xd" frameborder="0"></iframe>
    </section>


    <aside id="dereita">
    </aside>

    <?php
    include'footer.php';
    ?>
</body>
</html>