<html>
<?php
include'header2.php';

?>

<aside id="esquerda">

</aside>

    <section id="main">
        <div id="titulo">
            <h1>¿Quienes somos?</h1>
            <p>Somos una empresa de venta de productos Informáticos, estamos en este sector
                desde  2009, consiguiendo nuestros productos a grandes precios gracias a  las asociaciones 
                con las propias marcas fabricantes y ensambladoras.
            </p>
            <br/>
            <h1>¿Donde estamos?</h1>
            <p>Nuestras oficinas se localizam en el Polígono Santiago Sur Galicia donde se ecnuentra el
                almacen y el taller de reparación.
            </p>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2925.0673232905347!2d-8.585781584295878!3d42.85031161199179!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd2f036b897c5793%3A0x2648b8bc932e5fca!2sPol%C3%ADgono%20Santiago%20Sur%20Galicia!5e0!3m2!1ses!2ses!4v1607511330061!5m2!1ses!2ses" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
    </section>

    <aside id="dereita">

    </aside>



<?php
  include 'footer.php';
?>

  </body>
</html>
