<?php

echo "
<div id='botonnavegar'>
    <ul>";
    echo $pax;
    //$enlace_actual="";
    if(isset($_GET['paxina'])){

        if($pax > 1){
            echo "<li><a href='generarProductos.php?paxina=".$paxsig."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

        }
    }
    if($cont < $cantidad_prod[0]){
        echo "<li><a href='generarProductos.php?paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
    }


"</ul>";
echo "</div>";
?>