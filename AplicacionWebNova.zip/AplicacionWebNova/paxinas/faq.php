<html>
<?php
include'header2.php';

?>

<aside id="esquerda">

</aside>

    <section id="main">
        <div id="titulo">
            <h1>¿Como puedo devolver un articulo?</h1>
            <p>Puede devolver un articulo desde su pefil, pulsando en el botón devolver que estará
                al lado del artículo comprado.
            </p>
            <br/>
            <h1>¿Cuando puedo devolver un articulo?</h1>
            <p>Siempre que tenga la validez de la garantía que son 2 años
            </p>
            <br/>
            <h1>¿Como envío el producto?</h1>
            <p>Una vez tramitada la devolución un trabajador de la empresa de envíos pasará por 
                su domicilio para recoger el paquete 
            </p>
        </div>
    </section>

    <aside id="dereita">

    </aside>



<?php
  include 'footer.php';
?>

  </body>
</html>
