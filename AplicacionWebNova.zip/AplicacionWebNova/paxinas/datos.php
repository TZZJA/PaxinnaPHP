<html>
<?php
SESSION_START();
?>
    <head>
    <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    <link href='https://fonts.googleapis.com/css2?family=Open+Sans&display=swap' rel='stylesheet'/>
    <link rel='icon' type='image/gif' href='../imaxes/favicon.gif'/>
    </head>
    <body>
        <section id="central">
            <h1>Datos del usuario</h1>
                <div id="datos">
                    <div id="datos_usuario">
                        <form method='post' action="controlActualizar.php" enctype="multipart/form-data" target='_parent'>
                        <?php 
                            if(!empty($_SESSION)){
                                    echo "<ul>
                                            <li><label for='nome'>Nome:</label><input id='nome' type='text' name='nome' value='".$_SESSION["nombre"]."' required/></li>
                                            <li><label for='apelido'>Apelido 1:</label><input id='apelido'  type='text' name='apelido1' value='".$_SESSION["apellido"]."' required/></li>
                                            <li><label for='email'>Email:</label><input id='email' type='text' name='email' value='".$_SESSION["miSesion"]."' required/></li>
                                            <li><label for='telefono'>Telefono:</label><input id='telefono' type='text' name='telefono' value='".$_SESSION["telefono"]."' required/></li>
                                            <li><label for='contrasinal1'>Contraseña:</label><input id='contrasinal1' type='password' name='contrasinal1' required/></li>
                                            <li><label for='contrasinal2'>Repetir contraseña:</label><input id='contrasinal2' type='password' name='contrasinal2' required/></li>
                                            <li><label for='imaxe'>Imagen de perfil:</label><input id='imaxe' type='file' name='img_perfil'/></li>
                                            <br/>
                                            <input  id='bot_act' type='submit' name='actualizar' value='Actualizar'/>
                                        </ul>";                               
                            }
                        ?>
                        </form>
                    </div>
                </div>
               
        </section>
    </body>
</html>