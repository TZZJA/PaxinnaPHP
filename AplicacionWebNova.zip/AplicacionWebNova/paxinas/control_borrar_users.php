<?php

function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}


$id_user_buscado = valida('id_user');
$email_user_buscado = valida('email_user');

$id_user_buscadoOK = false;
$email_user_buscadoOK = false;

if($id_user_buscado == ""){
    echo "<h1>Id del usuario vacío</h1>";
}elseif(!is_numeric($id_user_buscado)){
    echo "<h1>El id del usuario tiene que ser un número</h1>";
}else{
    $id_user_buscadoOK = true;
}

if ($email_user_buscado == "") {
    print "  <h1>Non escribiu o email</h1>";
    print "\n";
}elseif(!preg_match("/^\w*[@]\w*.\w*$/", $email_user_buscado)){
    echo "<h1>Email mal formado</h1>";
}else {
    $email_user_buscadoOK = true;
}

if($email_user_buscadoOK && $id_user_buscadoOK){
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $borrado= "DELETE FROM usuarios WHERE id_usuario=".$id_user_buscado." AND email='".$email_user_buscado."'";
        $res = mysqli_query($db, $borrado);
        if($res){
            mysqli_close($db);
            echo "<h1>Borrado!</h1>";
        }else{
            echo "<h1>Non se borrou!</h1>";
            echo $borrado;
            mysqli_close($db);
        }

    }else {
        echo "<h1>mal conectado</h1>";
        mysqli_close($db);
    }
}

echo "<aside id='esquerda'>";
echo "</aside>";
echo "<section id='main'>"; 

?>