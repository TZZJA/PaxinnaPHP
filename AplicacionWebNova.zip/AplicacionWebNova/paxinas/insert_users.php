<html>
<head>
  <link href="../css/css.css" rel="stylesheet" type="text/css"/>
</head>
   <body>

  <?php  

   echo"        <form method='get' action='control_insert_users.php'>
                  <div class='ver'>
                    <label for='nom_user'>Nombre do usuario: </label><br/>
                    <input type='text' id='nom_user' name='nomuser'/><br/>

                    <label for='apel_user'>Apelido do usuario: </label><br/>
                    <input type='text' id='apel_user' name='apeluser'/><br/>

                    <label for='telefono'>Telefono: </label><br/>
                    <input type='tel' id='telefono' name='telefono' pattern='[0-9]{9}' maxlength='9'/><br/>

                    <label for='email_user'>Email: </label><br/>
                    <input type='text' id='email_user' name='email'/><br/>

                    <label for='contraseña'>Contraseña</label><br/>
                    <input type='password' id='contraseña' name='pass'/><br/>

                    <label for='confirm_contraseña'>Repetir Contraseña</label><br/>
                    <input type='password' id='confirm_contraseña' name='conf_pass'/><br/>
              
                    <label for='tipo_usuario'>Tipo de usuario: </label><br/>
                    <select name='select' id='tipoUser'>
                      <option value='admin'>Administrador</option> 
                      <option value='normal' selected>Normal</option>
                    </select><br>
                    
                    <input type='submit' name='insertar' value='Insertar!' />
                  </div>
                </form>";



?>


  </body>
</html>
