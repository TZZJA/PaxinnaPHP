<html id="jamau">
    <head>
    <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    </head>
    <body>
    <?php
        include'../datos/datos.php';
        

        
        if (isset($_GET["paxProd"])){
            if(($_GET["paxProd"]) > 0){
                $paxProd= $_GET["paxProd"];
            }
        }else{
            $paxProd=1;
        }

       
        if (isset($_GET["paxProd"])){
           if(($_GET["paxProd"]) >1 ){
                $paxProdant = --$_GET["paxProd"];
          } else {
                $paxProdant = null;
           }
       }
       
        $paxProdsig=$paxProd+1;
        
        
        
        $posProd=($paxProd-1)*6;
    ?>
        <form method="post" action="discos.php">
            <div id="filtros">


                 <ul id="campo4">
                    <select name="marcas">
                        <option value="marca1">AsRock</option>
                        <option value="marca1">Asus</option>
                        <option value="marca1">MSI</option>
                        <option value="marca1">Gigabyte</option>
                    </select>
                </ul>

                <ul id="campo1">
                    <li><input type="checkbox" name="1TB" id="1TB"/><label id="1TB">1Tb</label></li>
                    <li><input type="checkbox" name="2TB" id="2TB"/><label id="2TB">2Tb</label></li>
                    <li><input type="checkbox" name="3TB" id="3TB"/><label id="3TB">3Tb</label></li>
                </ul>
                
                <ul id="campo2">
                    <li><input type="checkbox" name="rpm1" id="7200rpm"/><label id="7200rpm">7200rpm</label></li>
                    <li><input type="checkbox" name="rpm2" id="5400rpm"/><label id="5400rpm">5400rpm</label></li>                   
                </ul>
                
                <ul id="campo3">
                    <li><input type="checkbox" name="ssd" id="ssd"/><label id="ssd">SSD</label></li>
                    <li><input type="checkbox" name="hdd" id="hdd"/><label id="hdd">HDD</label></li>
                </ul>
            </div>
        </form>
        <div id="prod">
        <?php
        $prod_count=count($productos);
        $final=false;
        $cont_tipoart=count($tipo_articulo);
        $encontradisco=false;
        $encontrarproducto=false;
        $arrayProd=array();
        
        for ($i=0; $i < $cont_tipoart; $i++){
            if ($tipo_articulo[$i]["nome_articulo"]=="disco_duro"){
                $articulo=$tipo_articulo[$i]["id_articulo"];
                $encontradisco=true;
                
                for ($k = 0; $k < $prod_count; $k++) {
                    if ($productos[$k]["id_articulo"] == $articulo) {
                        $productoBen=$productos[$k]["id_articulo"];
                        $encontrarproducto=true;                      
                        $arrayProd[]=$productos[$k];
                    }
                }                                 
            }
        }
//        $j=$posicion; (($j < ($posicion + 6)) && ($j < $prod_count)); $j++
        if (($encontradisco) && ($encontrarproducto) && ($articulo==$productoBen)){
            $contador=0;
            for ($j=$posProd; (($j < ($posProd + 6)) && ($j < count($arrayProd))); $j++) {
                
                    echo "<a href='generarArticulo.php?art=".$arrayProd[$j]['id_prod']."'>";
                    echo "<article class='imagen'>";
                    echo "<h2>"."<p>".$arrayProd[$j]['titulo']."</p>"."</h2>";
                    echo "<img src='../".$arrayProd[$j]['imaxe']."'>";
                    echo "<p id='prezo'>".$arrayProd[$j]['prezo']."$</p>";           
                    echo "</article>";
                    echo "</a>";
                    $contador++;
                    
                    if($j==(count($arrayProd)-1)){
                        $final=true;                   
                    }
                
            }

            include 'flechas2.php';
            
            
        }else {
            echo "Non hai discos";

        }

        ?>    

        </div>


    </body>
</html>