<html>
<?php

include 'header2.php';


?>
    <aside id="esquerda">
    </aside>


            <?php
                  $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                
              if(isset($_SESSION["id_usuario"])){
                  if($db){
                      $consulta = "SELECT id_prod FROM deseados WHERE id_usuario='".$_SESSION['id_usuario']."'";
                      $res = mysqli_query($db, $consulta);
                      if($res){
                          echo "
                                  <section id='main'>
                                    <center>
                                    <form method='post' action='controlpago.php'>
                                      <div>
                                      <h1>Carrito del usuario</h1>
                                      <div id='carrito'>";
                                        $total=0;
                                        $totalprod=0;
                                          while ($parametrosArticulo = mysqli_fetch_assoc($res)) {
                                              $consulta2 = "SELECT id_prod, titulo, prezo, imaxe FROM productos where id_prod='".$parametrosArticulo['id_prod']."'";
                                              $res2 = mysqli_query($db, $consulta2);
                                              $comprar = mysqli_fetch_assoc($res2);
                                              echo"
                                              <div class='carro'>
                                                  <div class='art'>
                                                      <img id='imgcarro' src='".$comprar['imaxe']."' />
                                                  </div>
                                                  <div class='art'>".$comprar['titulo']."</div>
                                                  <div class='art'>";
                                                  $cantidad = "SELECT cantidad FROM deseados WHERE id_prod = '".$parametrosArticulo['id_prod']."' AND id_usuario = '".$_SESSION['id_usuario']."'";
                                                  $res3 = mysqli_query($db, $cantidad);
                                                  $cant = mysqli_fetch_assoc($res3); 
                                          echo"   <p>Cantidade: ".$cant['cantidad']."</p>        
                                              </div>
                                                  <div class='art'>".$comprar['prezo']."$</div>                                                     
                                              </div>";
                                            $total = $total + ($comprar['prezo'] * $cant['cantidad']);
                                            $totalprod = $totalprod + $cant['cantidad'];
                                          
                                          
                                          }
                                          
                                          echo"<h1>Prezo total: $total $</h1>";

                                  echo "<br/>
                                        <label for='direccion'>Direccion de envío:</label>
                                        <input type='text' id='direccion' name='direccion'/>
                                        <label for='tarjeta'>Numero de tarjeta de credito(Amercian Express, Discovery, MasterCard, Visa):</label>
                                        <input type='text' id='tarjeta' name='tarjeta'/>
                                        <input type='submit' name='enviar' value='Comprar'/>
                                        <input type='hidden' name='precio' value='$total'/>
                                        <input type='hidden' name='total_prod' value='$totalprod'/>
                                        </div>
                                      </form>
                                      </center>
                                  ";
                                               
                          echo "      </div>
                                  </section>";
                      }
                  }else{
                      mysqli_close($db);
                  }
              }
            ?>


    <aside id="dereita">
    </aside>

<?php
  include 'footer.php';
?>

  </body>
</html>