<html>
<?php
include'header2.php';
?>


    <aside id="esquerda">
      <form>
        <p>Procesador <input type="radio" name="tipo" value="procesadores"></p><br/>
        <p>Almacenamento <input type="radio" name="tipo" value="almacenamento"></p><br/>
        <p>Perifericos <input type="radio" name="tipo" value="perifericos"></p><br/>
        <p>Ordenadores <input type="radio" name="tipo" value="ordenadores"></p><br/>
        <p>Cables <input type="radio" name="tipo" value="cables"></p><br/>
        <p>Casa <input type="radio" name="tipo" value="casa"></p><br/>
      </form>
    </aside>
    <section id="main">
        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

        <article>
          <h2>PROCESADOR RYZEN MODELO XXXX</h2>
          <img src="../imaxes/procesador.png"/>
          <p>310 &#8364;</p>
        </article>

    </section>

    <aside id="dereita">
      <a href="admin.php">Paxina a que acceder&aacute; o adminisrador</a><br/>
      <a href="usuario.php">Paxina perfil a que acceder&aacute;n os usuario</a><br/>
      <p>
        Lorem ipsum dolor sit amet consectetur adipiscing, elit morbi viverra praesent primis cum bibendum, pharetra velit duis dignissim varius. Iaculis malesuada potenti hendrerit risus justo bibendum consequat elementum placerat, suscipit euismod parturient varius tempus enim turpis diam lacus, lacinia feugiat eu orci taciti nisi nulla dictum. Purus fames nullam turpis sapien ullamcorper netus condimentum, donec pharetra mollis ultricies parturient tincidunt est pretium, vehicula integer maecenas nam aptent metus.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoque, arcu nascetur ante magna convallis nostra ac nunc urna. Purus fringilla tristique primis arcu diam ut accumsan nam dignissim elementum pretium, eu cursus leo neque nibh nunc nisl non hac a dapibus, mollis aptent odio montes sapien justo mauris pulvinar curabitur platea. Fusce orci placerat tellus taciti lectus mi iaculis primis parturient, sem aliquet ad mauris conubia massa blandit ullamcorper.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoqueLorem ipsum dolor sit amet consectetur adipiscing, elit morbi viverra praesent primis cum bibendum, pharetra velit duis dignissim varius. Iaculis malesuada potenti hendrerit risus justo bibendum consequat elementum placerat, suscipit euismod parturient varius tempus enim turpis diam lacus, lacinia feugiat eu orci taciti nisi nulla dictum. Purus fames nullam turpis sapien ullamcorper netus condimentum, donec pharetra mollis ultricies parturient tincidunt est pretium, vehicula integer maecenas nam aptent metus.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoque, arcu nascetur ante magna convallis nostra ac nunc urna. Purus fringilla tristique primis arcu diam ut accumsan nam dignissim elementum pretium, eu cursus leo neque nibh nunc nisl non hac a dapibus, mollis aptent odio montes sapien justo mauris pulvinar curabitur platea. Fusce orci placerat tellus taciti
      </p>
    </aside>


    <?php
      include 'paxinas/footer.php';
    ?>
  </body>
</html>
