<html>
<head>
<link href='../css/css.css' rel='stylesheet' type='text/css'/>
</head>
   <body>
        <div class="ver">
     
           <form method="post" action="mod_user.php" autocomplete="on">

                <label for="nom_user">Nombre del usuario: </label><br/>
                <input type="text" id="nom_user" name="nomuser"/><br/>

                <label for="apel_user">Apellido del usuario: </label><br/>
                <input type="text" id="apel_user" name="apeluser"/><br/>

                <label for="email_user">Email: </label><br/>
                <input type="text" id="email_user" name="email"/><br/><br/>

                <input type="submit" name="buscar" value="Buscar!!" />

            </form>

            </form method="post" action="mod_user.php">

                <label for="nom_user">Nombre del usuario: </label><br/>
                <input type="text" id="nom_user" name="nomuser"/><br/>

                <label for="apel_user">Apellido del usuario: </label><br/>
                <input type="text" id="apel_user" name="apeluser"/><br/>

                <label for="telefono">Telefono: </label><br/>
                <input type="tel" id="telefono" name="telefono" pattern="[0-9]{9}" maxlength="9"/><br/>

                <label for="email_user">Email: </label><br/>
                <input type="text" id="email_user" name="email"/><br/>

                <label for="contraseña">Contraseña</label><br/>
                <input type="password" id="contraseña" name="pass"/><br/>

                <label for="confirm_contraseña">Repetir Contraseña</label><br/>
                <input type="password" id="confirm_contraseña" name="conf_pass"/><br/>

                <label>Sexo: </label><br/>
                <select name="select">
                <option value="value1">Hombre</option> 
                <option value="value2" selected>Mujer</option>
                <option value="value2" >Prefiero no especificarlo</option>
                </select><br/>

                <label for="fecha_nacimiento">Fecha de nacimiento:</label><br/>
                <input type="date" id="fecha_nacimiento"/><br/><br/>

                <input type="submit" name="modificar" value="Modificar!" />

            </form>
        </div>

  </body>
</html>