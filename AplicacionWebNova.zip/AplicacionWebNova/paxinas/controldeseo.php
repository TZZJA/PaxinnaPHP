<?php

session_start();
$email = $_SESSION["miSesion"];


if(isset($_POST["deseo"])){
    $id_artigo = $_POST["oculto"];

    if($_SESSION["tipo"] == "admin"){
        header('Location: ../paxinas/soNormais.php');
    }elseif($_SESSION["tipo"] == "normal"){
        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
        if($db){
            $insercion = "INSERT INTO deseados (id_usuario, id_prod) VALUES (".$_SESSION['id_usuario'].", $id_artigo)";
            $res = mysqli_query($db, $insercion);
            print_r($res);
            if($res){
                header('Location: ../paxinas/generarArticulo1.php?art='.$id_artigo['oculto'].'');
            }
        }
        
    }
        

}