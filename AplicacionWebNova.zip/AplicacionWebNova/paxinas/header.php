<?php

SESSION_START();

if (!isset($_GET["buscar"])) $buscar="";
else  $buscar=$_GET["buscar"];

if (!isset($_GET["buscador"])) $buscador="";
else  $buscador=$_GET["buscador"];




if(!empty($_SESSION)) {

        
        if($_SESSION["tipo"] == "admin"){
              echo "<head>
                      <title>Mi pagina web</title>
                      <link href='css/css.css' rel='stylesheet' type='text/css'/>
                      <link href='https://fonts.googleapis.com/css2?family=Open+Sans&display=swap' rel='stylesheet'/>
                      <link rel='icon' type='image/gif' href='imaxes/favicon.gif'/>
                    </head>
                    <body>
                      <header>
                        <form method='get' action='paxinas/buscado.php'>
                          <div id='cabeceira'>
                            <ul id='campologo'>
                              <li><img id='logo' src='imaxes/logo.png'/></li>
                              <li><input class='flexsearch--input' type='search' name='buscador' /></li>
                            </ul>      
                          </div>
                        </form>
                      </header>
                    
                      <nav id='menu'>
                        <ul>     
                          <li><a class='men' href='inicio.php'>INICIO</a></li>
                          <li><a class='men' href='paxinas/productos.php'>PRODUCTOS</a></li>
                          <li><a class='men' href='paxinas/quen.php'>QUIENES SOMOS</a></li>
                          <li><a class='men' href='paxinas/faq.php'>FAQ</a></li>
                          <li class='dereita'><a class='men' href='paxinas/carro.php'><img  id='carro' src='imaxes/carrito.png' ></img></a></li>
                          <li id='despl'><a class='men'href='paxinas/admin.php'>".$_SESSION["miSesion"]."</a>
                            <ul id='desplegable'>
                                <li><a href='paxinas/salir.php'>SALIR</a></li>
                            </ul>
                          </li>
                        </ul>
                      </nav>";   
        }elseif($_SESSION["tipo"] == "normal"){
              
                  echo "<head>
                          <title>Mi pagina web</title>
                          <link href='css/css.css' rel='stylesheet' type='text/css'/>
                          <link href='https://fonts.googleapis.com/css2?family=Open+Sans&display=swap' rel='stylesheet'/>
                          <link rel='icon' type='image/gif' href='imaxes/favicon.gif'/>
                        </head>
                        <body>
                          <header>
                            <form method='get' action='paxinas/buscado.php'>
                              <div id='cabeceira'>
                                <ul id='campologo'>
                                  <li><img id='logo' src='imaxes/logo.png'/></li>
                                  <li><input class='flexsearch--input' type='search' name='buscador' /></li>
                                </ul>      
                              </div>
                            </form>
                          </header>

                          <nav id='menu'>
                            <ul>     
                              <li><a class='men' href='inicio.php'>INICIO</a></li>
                              <li><a class='men' href='paxinas/productos.php'>PRODUCTOS</a></li>
                              <li><a class='men' href='paxinas/quen.php'>QUIENES SOMOS</a></li>
                              <li><a class='men' href='paxinas/faq.php'>FAQ</a></li>
                              <li class='dereita'><a class='men' href='paxinas/carro.php?usuario=".$_SESSION["id_usuario"]."'><img  id='carro' src='imaxes/carrito.png' ></img></a></li>
                              <li id='despl'><a class='men'href='paxinas/usuario.php'>".$_SESSION["miSesion"]."</a>
                                <ul id='desplegable'>
                                    <li><a href='paxinas/salir.php'>SALIR</a></li>
                                </ul>
                              </li>
                            </ul>
                          </nav>";
          }
      
    
}else {
          echo "<head>
                  <title>Mi pagina web</title>
                  <link href='css/css.css' rel='stylesheet' type='text/css'/>
                  <link href='https://fonts.googleapis.com/css2?family=Open+Sans&display=swap' rel='stylesheet'/>
                  <link rel='icon' type='image/gif' href='imaxes/favicon.gif'/>
                </head>
                <body>
                  <header>
                    <form method='get' action='paxinas/buscado.php'>
                      <div id='cabeceira'>
                        <ul id='campologo'>
                          <li><img id='logo' src='imaxes/logo.png'/></li>
                          <li><input class='flexsearch--input' type='search' name='buscador'/></li>
                          
                        </ul>

                      </div>
                    </form>
                  </header>
                        
                  <nav id='menu'>
                    <ul>
                      <li><a class='men' href='inicio.php'>INICIO</a></li>
                      <li><a class='men' href='paxinas/productos.php'>PRODUCTOS</a></li>
                      <li><a class='men'href='paxinas/quen.php'>QUIENES SOMOS</a></li>
                      <li><a class='men'href='paxinas/faq.php'>FAQ</a></li>
                      <li class='dereita'><a class='men' href='paxinas/carro.php'><img  id='carro' src='imaxes/carrito.png' ></img></a></li>
                      <li><a class='men'href='paxinas/formulario.php'>LOGIN</a>
                      </li>
                    </ul>
                  </nav>";
}

?>

