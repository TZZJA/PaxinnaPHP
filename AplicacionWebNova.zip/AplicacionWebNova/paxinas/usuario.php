<html>
<?php
include'header2.php';
include'../datos/datos.php';

?>



    <aside id="esquerda">
      <div id="menuuser">
        <ul>
          <li><a href="datos.php" target="iframe_a">Mis Datos</a></li>
          <li><a href="pedidos.php" target="iframe_a">Ver Pedidos</a></li>
          <li><a href="deseos.php" target="iframe_a">Lista de deseos</a></li>
          <li><a href="devoluciones.php" target="iframe_a">Devoluciones</a></li>
        </ul>
    </div>
    </aside>

    <section id="main">
      <div id="userMain">
        <center>
        <?php 
        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");

        if($db){
          if(!empty($_SESSION)){
            echo"<img src='".$_SESSION['imaxe']."'/ id='fotoPerfil'>";
          }
        }

        ?>

        </center>
      </div>

      <iframe class="ver" src="" name="iframe_a" height="70%" width="80%" title="xd" frameborder="0"></iframe>



    </section>

    <aside id="dereita">
      <p>Lorem ipsum dolor sit amet consectetur adipiscing, elit morbi viverra praesent primis cum bibendum, pharetra velit duis dignissim varius. Iaculis malesuada potenti hendrerit risus justo bibendum consequat elementum placerat, suscipit euismod parturient varius tempus enim turpis diam lacus, lacinia feugiat eu orci taciti nisi nulla dictum. Purus fames nullam turpis sapien ullamcorper netus condimentum, donec pharetra mollis ultricies parturient tincidunt est pretium, vehicula integer maecenas nam aptent metus.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoque, arcu nascetur ante magna convallis nostra ac nunc urna. Purus fringilla tristique primis arcu diam ut accumsan nam dignissim elementum pretium, eu cursus leo neque nibh nunc nisl non hac a dapibus, mollis aptent odio montes sapien justo mauris pulvinar curabitur platea. Fusce orci placerat tellus taciti lectus mi iaculis primis parturient, sem aliquet ad mauris conubia massa blandit ullamcorper.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoqueLorem ipsum dolor sit amet consectetur adipiscing, elit morbi viverra praesent primis cum bibendum, pharetra velit duis dignissim varius. Iaculis malesuada potenti hendrerit risus justo bibendum consequat elementum placerat, suscipit euismod parturient varius tempus enim turpis diam lacus, lacinia feugiat eu orci taciti nisi nulla dictum. Purus fames nullam turpis sapien ullamcorper netus condimentum, donec pharetra mollis ultricies parturient tincidunt est pretium, vehicula integer maecenas nam aptent metus.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoque, arcu nascetur ante magna convallis nostra ac nunc urna. Purus fringilla tristique primis arcu diam ut accumsan nam dignissim elementum pretium, eu cursus leo neque nibh nunc nisl non hac a dapibus, mollis aptent odio montes sapien justo mauris pulvinar curabitur platea. Fusce orci placerat tellus taciti lectus mi iaculis primis parturient, sem aliquet ad mauris conubia massa blandit ullamcorper.Sagittis luctus viverra aenean eu conubia metus facilisi ut varius natoqueLorem ipsum dolor sit amet consectetur adipiscing, elit morbi viverra praesent primis cum bibendum, pharetra velit duis dignissim varius. Iaculis malesuada potenti </p>
    </aside>


    <?php
      include 'footer.php';
    ?>

  </body>
</html>
