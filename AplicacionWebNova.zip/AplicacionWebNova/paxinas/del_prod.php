<html>
<head>
  <link href='../css/css.css' rel='stylesheet' type='text/css'/>
</head>
   <body>

           <form method='post' action='del_prod.php'>
              <div class='ver'>
              <label for="buscar_prod">Nome do producto: </label><br/>
                <input  id='buscar_prod' type='text' name='prod_buscar'/>
                <input type='submit' name='enviar' value='buscar'/>
              </div>
           </form>
           <?php
            session_start();

            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
            if(isset($_POST['prod_buscar'])){
                if($db){
                  $consulta = "SELECT distinct * FROM productos WHERE titulo LIKE '%".$_POST['prod_buscar']."%'";
                  $res = mysqli_query($db, $consulta);
                  if($res){
                    while ($datos_buscados = mysqli_fetch_assoc($res)) {
                      echo "Id: $datos_buscados[id_prod], Nombre do producto: $datos_buscados[titulo], Prezo: $datos_buscados[prezo]<br/>";
                    }
                    mysqli_close($db);
                  }
                }else{
                  mysqli_close($db);
                  echo "Mal conectado";
                }
              }
           ?>
           <form method="post" action="control_borrar_prod.php" autocomplete="on">
              <div class="ver">
                <label for="id_prod">Id do producto: </label><br/>
                <input type="number" id="id_prod" name="id_prod"/><br/>

                <label for="nom_prod">Nombre do producto: </label><br/>
                <input type="text" id="nom_prod" name="nom_prod"/><br/><br/>


                <input type="submit" name="borrar" value="Borrar!" />
              </div>

            </form>





  </body>
</html>