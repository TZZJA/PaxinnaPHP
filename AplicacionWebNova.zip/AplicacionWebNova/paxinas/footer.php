<?php
echo "    <footer id='pie'>
      <p>ERO GARRIDO BESADA</p>
      <p>2º ASIR</p>
    </footer>";
?>
