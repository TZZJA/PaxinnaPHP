<html>
  <head>
<?php
include'header2.php';
?>


    <aside id="esquerda">
    </aside>
    <section id="main">
        <form method="post" action="control_login.php" id="login">
          <center>
          <h1>INICIAR SESION</h1>
          <!-- <p>Email:</p><input type="email" name="usuarioEmail" pattern=".+@globex.com" required/><br/> -->
          <p>Email:</p><input type="email" name="usuarioEmail" required/><br/>
          <p>Contrasinal:</p><input type="password" name="contrasinal"/><br/>
          <input type="submit" name="Enviar" value="Enviar"/>
        </center>

        </form>
        <br/>
        <form method="post" action="control_registro.php" id="rex">
          <center>
            <h1>REXISTRARSE</h1>
            <p>Nome:</p><input type="text" name="nome" required/><br/>
            <p>Primer Apelido:</p><input type="text" name="apelido1" required/><br/>
            <p>Email:</p><input type="email" name="email" required/><br/>
            <p>Telefono:</p><input type="text" name="telefono" required/><br/>
            <p>Contrasinal:</p><input type="password" name="contrasinal1" required/><br/>
            <p>Repetir Contrasinal:</p><input type="password" name="contrasinal2" required/><br/>
            <input type="submit" name="rexistro" value="Rexistrarme!"/>
          </center>
        </form>
    </section>

    <aside id="dereita">
    </aside>


    <?php
      include 'footer.php';
    ?>

  </body>
</html>
