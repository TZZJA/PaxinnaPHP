<html>
    <head>
        <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    </head>
   <body>

  <?php  
                    
       echo "<br/>";
       echo "

       ";
       echo " <form method='POST' action='control_prod.php' method='get' enctype='multipart/form-data'>
                <div class='tags'>
                  <ul id='tags'>
                    <li>EXEMPLO DE INSERCION DE CARACTERISTICAS.</li>
                    <li>DEBE RESPETAR O SEGUINTE FORMATO:</li><br/>
                    <li>Para procesadores: Nucleos:8;</li>
                    <li>Para discos duros: Capacidad:7200;</li>
                    <li>Para placas base: Chipset:atx;</li>
                    <li>Para tarxetas graficas: Tipo:GTX 1080;</li>
                    <li>Para ratóns: Tipo:inalambrico;</li>
                    <li>Para teclados: Tipo:membrana;</li>
                    <li>Para monitores: Tipo:curvo;</li>
                    <li>Para disipación: Disipacion:liquida;</li>
                    <li>Para caixas: Formato:miniitx;</li>
                    <li>Para televisions: Resolucion:4096x2160;</li>
                    <li>Para cascos: Conexion:jack35;</li>
                    <li>Para micros: Micro:dinamico;</li>
                  </ul>
                </div>
                <div class='verprod'>
                  <label for='nomeart'>Titulo do articulo: </label><br/>
                  <input type='text' id='nomeart' name='nom_art'/><br/>

                  <label for='tipoart'>Tipo de Articulo </label><br/>";
                  $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                  if($db){
                    $consulta = "SELECT * FROM tipo_articulo";
                    $res = mysqli_query($db, $consulta);
                    if($res){
                      echo"<select name='tipo' id='tipoart'>";
                      while ($articulos = mysqli_fetch_assoc($res)) {                                  
                          echo "<option value=".$articulos['id_articulo'].">".$articulos['nome_articulo']."</option>";                               
                      }
                      echo"</select><br/>";
                      mysqli_close($db);
                    }
                    
                  }else {
                    mysqli_close($db);
                  }
              echo"<label for='marca'>Marca </label><br/>";
              $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
              if($db){
                $consulta2 = "SELECT * FROM marca";
                $res2 = mysqli_query($db, $consulta2);
                if($res2){
                  echo"<select name='marca' id='marca'>";
                  while ($marca = mysqli_fetch_assoc($res2)) {                                  
                      echo "<option value=".$marca['id_marca'].">".$marca['nome_marca']."</option>";                               
                  }
                  echo"</select><br/>";
                  mysqli_close($db);
                }
                
              }else {
                mysqli_close($db);
              }

              


                 echo "<label for='caract'>Caracteristicas: </label><br/>
                  <textarea id='caract' name='carc_art'></textarea><br/>

                  <label for='descrip'>Descripcion: </label><br/>
                  <textarea id='descrip' name='descrip_art'></textarea><br/>

                  <label for='prezprod'>Prezo</label><br/>
                  <input type='number' id='prezoprod' name='prezo'/><br/>

                  <label for='imaxe'>Imaxe do producto</label><br/>
                  <input type='file' id='imaxe' name='img_prod' required/><br/>
            

                  <input type='submit' name='insertar' value='Insertar!' />
                </div>

             </form>";
?>




  </body>
</html>