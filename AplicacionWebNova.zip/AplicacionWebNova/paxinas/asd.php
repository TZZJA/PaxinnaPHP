<?php
        if(isset($_POST['micro']) && isset($_POST['prezo']) && isset($_POST['marca'])){

            if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['micro'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }elseif(!empty($_POST['micro']) && !empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' order by prezo desc";
            }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
            }elseif(!empty($_POST['micro']) && !empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%micro:".$_POST['micro']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' ";
            }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' order by prezo desc ";
            }elseif(empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' order by prezo desc ";
            }elseif(empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' ";
            }elseif(empty($_POST['micro'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }
        }


?>