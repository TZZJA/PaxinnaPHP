<html>
<head>
  <link href='../css/css.css' rel='stylesheet' type='text/css'/>
</head>
   <body>

           <form method='post' action='del_users.php'>
              <div class='ver'>
              <label for="buscar_user">Nombre do usuario: </label><br/>
                <input  id='buscar_user' type='text' name='user_buscar'/>
                <input type='submit' name='enviar' value='buscar'/>
              </div>
           </form>
           <?php
            session_start();

            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
            if(isset($_POST['user_buscar'])){
                if($db){
                  $consulta = "SELECT distinct * FROM usuarios WHERE nombre='".$_POST['user_buscar']."'";
                  $res = mysqli_query($db, $consulta);
                  if($res){
                    while ($datos_buscados = mysqli_fetch_assoc($res)) {
                      echo "Id: $datos_buscados[id_usuario], Nombre: $datos_buscados[nombre], Apellido: $datos_buscados[apellido],Telefono: $datos_buscados[telefono],Email $datos_buscados[email]<br/>";
                    }
                    mysqli_close($db);
                  }
                }else{
                  mysqli_close($db);
                  echo "Mal conectado";
                }
              }
           ?>
           <form method="post" action="control_borrar_users.php" autocomplete="on">
              <div class="ver">
                <label for="id_user">Id do usuarios: </label><br/>
                <input type="number" id="id_user" name="id_user"/><br/>

                <label for="email_user">Email: </label><br/>
                <input type="text" id="email_user" name="email_user"/><br/><br/>


                <input type="submit" name="borrar" value="Borrar!" />
              </div>

            </form>





  </body>
</html>
