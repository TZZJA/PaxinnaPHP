<?php
include'header2.php';
function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}
$emailLogin = valida("usuarioEmail");
$passLogin  = valida("contrasinal");

$emailLoginOK = false;
$passLoginOK = false;

echo "<aside id='esquerda'>";
echo "</aside>";

echo "<section id='main'>"; 

if ($emailLogin == "") {
    print "  <p class=\"aviso\">Non escribiu o correo para Logearte</p>\n";
    print "\n";
}elseif(!preg_match("/^\w*[@]\w*.\w*$/", $emailLogin)){
    echo "Email mal formado";
}else {
    $emailLoginOK= true;
}

if (($passLogin == "")) {
    print "  <p class=\"aviso\">O contrasinal está vacio</p>\n";
    print "\n";
}else {
    $passLoginOK= true;
}




if(($emailLoginOK) && ($passLoginOK)){

    
    $logerror=null;
    
    $db=mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    
    if($db){
        $conUsers = "SELECT id_usuario, nombre, apellido, telefono, imaxe, email, contrasenha, tipo FROM usuarios where email = '$emailLogin'";
        $ejecutar_a= mysqli_query($db, $conUsers);
              
        if($ejecutar_a){

                $usuarios= mysqli_fetch_assoc($ejecutar_a);
                $filas = mysqli_num_rows($ejecutar_a);
                if($filas > 0){
                        if(($usuarios['contrasenha']== $passLogin) && ($usuarios['email'] == $emailLogin)){
                            if($usuarios["tipo"] == "normal"){
                                SESSION_START();
                                $_SESSION["id_usuario"] = $usuarios["id_usuario"];
                                $_SESSION["nombre"] = $usuarios["nombre"];
                                $_SESSION["apellido"] = $usuarios["apellido"];
                                $_SESSION["telefono"] = $usuarios["telefono"];
                                $_SESSION["miSesion"]= $emailLogin;
                                $_SESSION["imaxe"]= $usuarios["imaxe"];
                                $_SESSION["tipo"]= $usuarios["tipo"];
                                header('Location: ../paxinas/usuario.php');
                            }else{
                                SESSION_START();
                                $_SESSION["id_usuario"] = $usuarios["id_usuario"];
                                $_SESSION["nombre"] = $usuarios["nombre"];
                                $_SESSION["apellido"] = $usuarios["apellido"];
                                $_SESSION["telefono"] = $usuarios["telefono"];
                                $_SESSION["miSesion"]= $emailLogin;
                                $_SESSION["imaxe"]= $usuarios["imaxe"];
                                $_SESSION["tipo"]= $usuarios["tipo"];
                                header('Location: ../paxinas/admin.php');
                            }
                        }else{
                            echo "<h1>La contraseña o el email no coincide </h1><br/>";
                        }
                }else{
                    echo "<h1>El usuario no existe</h1>";
                }

                


                
               
        }else {
            echo "Mal seleccionado";
        }
    }else{
        echo "Non se pudo conectar";
    }
    
    
    }
    echo "</section>"; 
    echo "<aside id='dereita'>";
    echo "</aside>";
    include'../paxinas/footer.php';
?>