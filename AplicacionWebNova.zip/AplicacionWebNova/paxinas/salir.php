<html>
    <head>
        <link href='../css/css.css' rel='stylesheet' type='text/css'/>
        <link href='https://fonts.googleapis.com/css2?family=Open+Sans&display=swap' rel='stylesheet'/>
    </head>

<?php
include'header2.php';
include'../datos/datos.php';
$tiempo=5000000;
      function esperar($tiempo){
          echo "Volverás a la pagina de inicio";
          usleep($tiempo);
          session_unset();
          session_destroy();
          header('Location: ../inicio.php');        
        }
?>


    <aside id="esquerda">

    </aside>

    <section id="main"> 
      
        
        <?php

          echo esperar($tiempo);

            
            
            
           
        ?>

    </section>

    <aside id="dereita">

    </aside>

<?php
  include '../paxinas/footer.php';
?>

  </body>
</html>
