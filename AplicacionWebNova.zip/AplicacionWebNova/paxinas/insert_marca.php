<html>
    <head>
        <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    </head>
   <body>

  <?php  
                    
       echo "<br/>";
       echo " <form method='POST' action='control_marca.php' method='get'>
                <div class='ver'>
                  <label for='nomemarca'>Nome da marca: </label><br/>
                  <input type='text' id='nomemarca' name='nomemarca'/><br/>
                  <input type='submit' name='insertar' value='Insertar!' />
                </div>

             </form>";
?>




  </body>
</html>