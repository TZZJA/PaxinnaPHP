<html>
<?php

include'header2.php';
$db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
$x='';
$cont;
$abuscar=$_GET["buscador"];
if($db){
  $consulta2= "SELECT count(id_prod) FROM productos where titulo LIKE '%$abuscar%' OR prezo LIKE '%$abuscar%'";
  $res2 = mysqli_query($db, $consulta2);
  $cantidad_prod = mysqli_fetch_row($res2);
  //print_r($cantidad_prod);
  mysqli_close($db);
}

if (isset($_GET["paxina"])){
  if(($_GET["paxina"]) >0){
    $pax = $_GET["paxina"];    
  }
}else{
  $pax=1;
}

if (isset($_GET["paxina"])){
  if(($_GET["paxina"]) >1){
    $paxant= --$_GET["paxina"];
    
  }else{
    $paxant=null;
  }
}

$paxsig = $pax + 1;
if (isset($_GET["paxina"])){
  if(($_GET["paxina"]) >0){
    //$pax=$_GET["paxina"];
    $x=($pax-1)*6;
    $cont=($pax-1)*6;
    echo "<aside id='esquerda'>";

    echo "</aside>";

    echo "<section id='main'>"; 
    //REALIZAR CONEXION COA BASE DE DATOS

    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){      
      $consulta = "SELECT id_prod, titulo, prezo, imaxe FROM productos where titulo LIKE '%$abuscar%' OR prezo LIKE '%$abuscar%' LIMIT $x,6";
      echo "<br/>";
      echo "<h1>Resultados para ".$abuscar."</h1>";
      $res = mysqli_query($db, $consulta);          
      if($res){
        while($prod = mysqli_fetch_assoc($res)){          
          echo "<a href='paxinas/articulo.php?art=".$prod['id_prod']."'>";
            echo "<article>";
              echo "<h2>"."<p>".$prod['titulo']."</p>"."</h2>";
              echo "<img src=".$prod['imaxe'].">";
              echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
            echo "</article>";
          echo "</a>";
          $cont++;
        }
        
        mysqli_close($db);
      }else{
        echo "Non seleccionado";
      }
    }else {
      echo "Error ao conectarme a Base de Datos";
    }
    echo "
    <div id='botonnavegar'>
        <ul>";
        //$enlace_actual="";
        if(isset($_GET['paxina'])){

            if($pax > 1){
                echo "<li><a href='buscado.php?buscador=$abuscar&paxina=".$paxant."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

            }
        }
        if($cont < $cantidad_prod[0]){
            echo "<li><a href='buscado.php?buscador=$abuscar&paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
        }


        "</ul>";
echo "</div>";
  }
 
}else{
  $cont='';
  echo "<aside id='esquerda'>";

  echo "</aside>";
  $paxsig=$pax+1;
  echo "<section id='main'>"; 
  //REALIZAR CONEXION COA BASE DE DATOS

  $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
  if($db){
    $consulta = "SELECT id_prod, titulo, prezo, imaxe FROM productos where titulo LIKE '%$abuscar%' OR prezo LIKE '%$abuscar%' LIMIT 0,6";
    echo "<br/>";
    $res = mysqli_query($db, $consulta);          
    if($res){
      echo "<h1>Resultados para ".$abuscar."</h1>";
      while($prod = mysqli_fetch_assoc($res)){                  
        echo "<a href='paxinas/articulo.php?art=".$prod['id_prod']."'>";
        echo "<article>";
          echo "<h2>"."<p>".$prod['titulo']."</p>"."</h2>";
          echo "<img src=".$prod['imaxe'].">";
          echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
        echo "</article>";
        echo "</a>";
        $cont++;
      }
      
      mysqli_close($db);
    }else{
      echo "Non seleccionado";
    }
  }else {
    echo "Error ao conectarme a Base de Datos";
  }
  echo "
<div id='botonnavegar'>
    <ul>";
    //$enlace_actual="";
    if(isset($_GET['paxina'])){

        if($pax > 1){
            echo "<li><a href='buscado.php?buscador=$abuscar&paxina=".$paxant."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

        }
    }
    if($cont < $cantidad_prod[0]){
        echo "<li><a href='buscado.php?buscador=$abuscar&paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
    }


"</ul>";
echo "</div>";

}

//if(isset($_GET["paxina"])){
//  $paxsig=$_GET["paxina"]+1;
//}

?>

</section>
    <aside id="dereita">
      <a href="paxinas/admin.php">Paxina a que acceder&aacute; o adminisrador</a><br/>
      <a href="paxinas/usuario.php">Paxina perfil a que acceder&aacute;n os usuario</a><br/>
      
    </aside>

<?php
  include 'footer.php';
?>

  </body>
</html>