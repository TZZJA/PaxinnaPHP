<html>
    <?php
        include'header2.php';
    ?>
    <body> 
<?php

    if (!isset($_GET["comprar"])) $comprar="";
    else $comprar=$_GET["comprar"];
    $idartigo = $_GET["art"];
    echo "<aside id='esquerda'>";
    echo "</aside>";

    $idArtigo=$_GET["art"];
    $delimitador=";";
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){

        $consulta = "SELECT id_prod, titulo, caracteristicas, descripcion, prezo, imaxe from productos where id_prod=$idArtigo";

        $res = mysqli_query($db, $consulta);

        if($res ){

      
            while ($artGen = mysqli_fetch_assoc($res)) {
                $cadena_caracter = $artGen['caracteristicas'];
                $caract = explode($delimitador, $cadena_caracter);
                $cont_caract= count($caract);

            
                        echo    "<section id='art'>
                                    <article id='prod'>
                                            <div class='container'>
                                                <ul class='slider'>
                                                    <li id='slide1'>";
                                                    echo"<img src=imaxesproductos/../".$artGen['imaxe'].">";
                            echo "                   </li>
                                                </ul>
                                            </div>
                                            <div id='info'>
                                                <h2>".$artGen['titulo']."</h2>";
                                                    for ($j=0; $j<$cont_caract; $j++){
                                                    echo "<p>".$caract[$j]."</p>";
                                                    }
                                            echo "<p><b>".$artGen["descripcion"]."</b></p>";
                                            echo "<h1 id='prezo'>".$artGen["prezo"]."$"."</h1>";
                            echo            "</div>";
                                            if(!empty($_SESSION)){
                                                echo "
                                                <div id='botons'>
                                                    <div>
                                                        <form method='post' action='controldeseo.php'>
                                                            <input id='boton_deseo' type='submit' name='deseo' value='Añadir a deseados'/>
                                                            <input type='hidden' name='oculto' value='$artGen[id_prod]'/>
                                                        </form>
                                                    </div>
                                                    <div>
                                                        <form method='post' action='controlcarro.php'>
                                                            <input id='boton_comprar' type='submit' name='comprar' value='Comprar'/>
                                                            <input type='hidden' name='oculto' value='$artGen[id_prod]'/>
                                                        </form>
                                                    </div>
                                                </div>
                                                ";    
                                                
                                                
                                            }else{
                                                echo "
                                                <div id='botons'>
                                                    <h3>Rexistrate ou logeate para comprar!</h3>
                                                </div>
                                                "; 
                                            }
                                          
                            echo    "</article>
                                 </section>";
             }

        }else{
            echo "Mal seleccionado";
        }
        
    }else{
        echo "Non se conectou";
    }
    echo "
        <aside id='dereita'>
    </aside>
    ";
    include'footer.php';
?>
    </body>
</html>
