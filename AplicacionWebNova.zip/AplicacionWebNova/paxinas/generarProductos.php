<html id="productos">
    <head>
    <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    </head>
    <body>
    <?php
        include'../datos/datos.php';
        
        $variable = $_GET["prod"];
        //print_r($_GET);
        
        $x='';
        $enlace_actual = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        //echo $enlace_actual;

        if (isset($_GET["paxina"])){
            if(($_GET["paxina"]) >0){
                $pax = $_GET["paxina"];
                $x=($pax-1)*6;
                $cont=($pax-1)*6;
                $paxsig=$pax+1;    
            }
        }else{
            $pax=1;
            $cont='';
            $x=0;
            $paxsig=$pax+1; 
        }

        if (isset($_GET["paxina"])){
            if(($_GET["paxina"]) >1){
              $pax = $_GET["paxina"];
              $paxant= --$_GET["paxina"];
              $variable = $_GET["prod"];
              $paxsig=$pax+1;
              $x=($pax-1)*6;
              $cont=($pax-1)*6;
                           
            }else{
              $paxant=null;

            }
        }
        //echo $pax;

        if($variable == 1){
    
    //FORMULARIO TAGS DE PROCESADORES
                echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                        
                            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                            $i=0;
                            if($db){                       
                                $cons='SELECT * FROM marca';
                                $res = mysqli_query($db, $cons);
                                    if($res){
                                        echo"Marca: <select name='marca'>";
                                                echo "<option value=''>---</option>";
                                            while($marcas = mysqli_fetch_assoc($res)){                                    
                                                echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                            }                               
                                                echo"</select>";
                                        
                                    }else{
                                        echo "<h1>Erro ao facer a consulta</h1>";
                                    }                       
                                
                            }else{
                                echo "<h1>Non se conecta a BD</h1>";
                            }
                            
                        
                    echo "Nucleos: <select name='nucleos'>
                                        <option value=''>---</option>
                                        <option value='4'>4</option>
                                        <option value='6'>6</option>
                                        <option value='8'>8</option>
                                        <option value='12'>12</option>
                                   </select>  ";

                        echo "Prezo: <input type='number' name='prezo'>";
                        echo "<input type='submit' name='buscar' value='buscar'>";
                echo "</form>";

        }elseif($variable == 2 ){

    //FORMULARIO TAGS DE DISCOS DUROS
                echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                            
                        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                        $i=0;
                        if($db){                       
                            $cons='SELECT * FROM marca';
                            $res = mysqli_query($db, $cons);
                                if($res){
                                    echo"Marca: <select name='marca'>";
                                                echo "<option value=''>---</option>";
                                            while($marcas = mysqli_fetch_assoc($res)){                                    
                                                echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                            }                               
                                            echo"</select>";
                                    
                                }else{
                                    echo "<h1>Erro ao facer a consulta</h1>";
                                }                       
                            
                        }else{
                            echo "<h1>Non se conecta a BD</h1>";
                        }
                
                        echo "Capacidad: <select name='capacidad'>
                                            <option value=''>---</option>
                                            <option value='1TB'>1TB</option>
                                            <option value='250MB'>250MB</option>
                                            <option value='500MB'>500MB</option>
                                            <option value='800MB'>800MB</option>
                                         </select>";

                    echo "Prezo: <input type='number' name='prezo'>";
                    echo "<input type='submit' name='buscar' value='buscar'>";
                echo "</form>";

        }
        elseif($variable == 3){
            //FORMULARIO TAGS DE DISCOS DUROS
                echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                                
                    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                    $i=0;
                    if($db){                       
                        $cons='SELECT * FROM marca';
                        $res = mysqli_query($db, $cons);
                            if($res){
                                echo"Marca: <select name='marca'>";
                                        echo "<option value=''>---</option>";
                                    while($marcas = mysqli_fetch_assoc($res)){                                    
                                        echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                    }                               
                                        echo"</select>";
                                
                            }else{
                                echo "<h1>Erro ao facer a consulta</h1>";
                            }                       
                        
                    }else{
                        echo "<h1>Non se conecta a BD</h1>";
                    }
            
                    echo "Chipset: <select name='chipset'>
                                        <option value=''>---</option>
                                        <option value='B550'>B550</option>
                                        <option value='B450'>B450</option>
                                        <option value='B350'>B350</option>
                                        <option value='x470'>x470</option>
                                        <option value='x570'>x570</option>
                                        <option value='x670'>x670</option>

                                    </select>";

                echo "Prezo: <input type='number' name='prezo'>";
                echo "<input type='submit' name='buscar' value='buscar'>";
            echo "</form>";
            
        }
        elseif($variable == 4 ){
              //FORMULARIO TAGS DE TARJETAS GRAFICAS
              echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                                
              $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
              $i=0;
              if($db){                       
                  $cons='SELECT * FROM marca';
                  $res = mysqli_query($db, $cons);
                      if($res){
                          echo"Marca: <select name='marca'>";
                                  echo "<option value=''>---</option>";
                              while($marcas = mysqli_fetch_assoc($res)){                                    
                                  echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                              }                               
                                  echo"</select>";
                          
                      }else{
                          echo "<h1>Erro ao facer a consulta</h1>";
                      }                       
                  
              }else{
                  echo "<h1>Non se conecta a BD</h1>";
              }
      
              echo "Modelo: <select name='tipo'>
                                  <option value=''>---</option>
                                  <option value='GTX 1080'>GTX 1080</option>
                                  <option value='GTX 1070'>GTX 1070</option>
                                  <option value='GTX 1060'>GTX 1060</option>
                                  <option value='GTX 1050'>GTX 1050</option>
                                  <option value='RX 5700'>RX 5700</option>
                                  <option value='RX 5600'>RX 5600</option>
                                  <option value='RX 5500'>RX 5500</option>

                              </select>";

          echo "Prezo: <input type='number' name='prezo'>";
          echo "<input type='submit' name='buscar' value='buscar'>";
      echo "</form>";
        }
        elseif($variable == 5 ){
            //FORMULARIO TAGS DE RATONES
            echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                                
            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
            $i=0;
            if($db){                       
                $cons='SELECT * FROM marca';
                $res = mysqli_query($db, $cons);
                    if($res){
                        echo"Marca: <select name='marca'>";
                                echo "<option value=''>---</option>";
                            while($marcas = mysqli_fetch_assoc($res)){                                    
                                echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                            }                               
                                echo"</select>";
                        
                    }else{
                        echo "<h1>Erro ao facer a consulta</h1>";
                    }                       
                
            }else{
                echo "<h1>Non se conecta a BD</h1>";
            }
    
            echo "Tipo de ratón: <select name='raton'>
                                <option value=''>---</option>
                                <option value='cable'>Con cable</option>
                                <option value='inalámbrico'>Inalámbrico</option>
                                <option value='laser'>Laser</option>
                                <option value='óptico'>Óptico</option>
                                <option value='táctil'>Táctil</option>
                        </select>";

                echo "Prezo: <input type='number' name='prezo'>";
                echo "<input type='submit' name='buscar' value='buscar'>";
            echo "</form>";
        }
        elseif($variable == 6 ){
                        //FORMULARIO TAGS DE TECLADOS
                        echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                                
                        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                        $i=0;
                        if($db){                       
                            $cons='SELECT * FROM marca';
                            $res = mysqli_query($db, $cons);
                                if($res){
                                    echo"Marca: <select name='marca'>";
                                            echo "<option value=''>---</option>";
                                        while($marcas = mysqli_fetch_assoc($res)){                                    
                                            echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                        }                               
                                            echo"</select>";
                                    
                                }else{
                                    echo "<h1>Erro ao facer a consulta</h1>";
                                }                       
                            
                        }else{
                            echo "<h1>Non se conecta a BD</h1>";
                        }
                
                        echo "Switches: <select name='switches'>
                                            <option value=''>---</option>
                                            <option value='mecanico'>Mecánico</option>
                                            <option value='membrana'>Membrana</option>
                                            <option value='optomecanico'>Optomecánico</option>
                                    </select>";
            
                            echo "Prezo: <input type='number' name='prezo'>";
                            echo "<input type='submit' name='buscar' value='buscar'>";
                        echo "</form>";
        }
        elseif($variable == 7 ){
                        //FORMULARIO TAGS DE MONITORES
                        echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
                    
                        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                        $i=0;
                        if($db){                       
                            $cons='SELECT * FROM marca';
                            $res = mysqli_query($db, $cons);
                                if($res){
                                    echo"Marca: <select name='marca'>";
                                            echo "<option value=''>---</option>";
                                        while($marcas = mysqli_fetch_assoc($res)){                                    
                                            echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                        }                               
                                            echo"</select>";
                                    
                                }else{
                                    echo "<h1>Erro ao facer a consulta</h1>";
                                }                       
                            
                        }else{
                            echo "<h1>Non se conecta a BD</h1>";
                        }
                
                        echo "Tipo de Monitor: <select name='panel'>
                                            <option value=''>---</option>
                                            <option value='ips'>IPS</option>
                                            <option value='lcd'>LCD</option>
                                            <option value='oled'>OLED</option>
                                            <option value='3d'>3D</option>
                                            <option value='curvo'>CURVO</option>
                                    </select>";
            
                            echo "Prezo: <input type='number' name='prezo'>";
                            echo "<input type='submit' name='buscar' value='buscar'>";
                        echo "</form>";
        }
        elseif($variable == 8 ){
                        //FORMULARIO TAGS DE DISIPACIÓN
                        echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";
        
                        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                        $i=0;
                        if($db){                       
                            $cons='SELECT * FROM marca';
                            $res = mysqli_query($db, $cons);
                                if($res){
                                    echo"Marca: <select name='marca'>";
                                            echo "<option value=''>---</option>";
                                        while($marcas = mysqli_fetch_assoc($res)){                                    
                                            echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                        }                               
                                            echo"</select>";
                                    
                                }else{
                                    echo "<h1>Erro ao facer a consulta</h1>";
                                }                       
                            
                        }else{
                            echo "<h1>Non se conecta a BD</h1>";
                        }
                
                        echo "Tipo de Disipación: <select name='disipacion'>
                                            <option value=''>---</option>
                                            <option value='aire'>Aire</option>
                                            <option value='liquida'>Líquida</option>
                                    </select>";
            
                            echo "Prezo: <input type='number' name='prezo'>";
                            echo "<input type='submit' name='buscar' value='buscar'>";
                        echo "</form>";
        }
        elseif($variable == 9 ){
                        //FORMULARIO TAGS DE DISIPACIÓN
                        echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";

                        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                        $i=0;
                        if($db){                       
                            $cons='SELECT * FROM marca';
                            $res = mysqli_query($db, $cons);
                                if($res){
                                    echo"Marca: <select name='marca'>";
                                            echo "<option value=''>---</option>";
                                        while($marcas = mysqli_fetch_assoc($res)){                                    
                                            echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                        }                               
                                            echo"</select>";
                                    
                                }else{
                                    echo "<h1>Erro ao facer a consulta</h1>";
                                }                       
                            
                        }else{
                            echo "<h1>Non se conecta a BD</h1>";
                        }
                
                        echo "Tipo de Caja: <select name='caja'>
                                            <option value=''>---</option>
                                            <option value='atx'>ATX</option>
                                            <option value='microatx'>micro-ATX</option>
                                            <option value='eatx'>EATX</option>
                                            <option value='miniitx'>mini-ITX</option>
                                    </select>";
            
                            echo "Prezo: <input type='number' name='prezo'>";
                            echo "<input type='submit' name='buscar' value='buscar'>";
                        echo "</form>";
        }
        elseif($variable == 10 ){
                        //FORMULARIO TAGS DE TELEVISIONS
                        echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";

                        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
                        $i=0;
                        if($db){                       
                            $cons='SELECT * FROM marca';
                            $res = mysqli_query($db, $cons);
                                if($res){
                                    echo"Marca: <select name='marca'>";
                                            echo "<option value=''>---</option>";
                                        while($marcas = mysqli_fetch_assoc($res)){                                    
                                            echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                                        }                               
                                            echo"</select>";
                                    
                                }else{
                                    echo "<h1>Erro ao facer a consulta</h1>";
                                }                       
                            
                        }else{
                            echo "<h1>Non se conecta a BD</h1>";
                        }
                
                        echo "Tipo de Caja: <select name='resolucion'>
                                            <option value=''>---</option>
                                            <option value='1920x1080'>1920x1080(Full HD)</option>
                                            <option value='3840x2160'>3840x2160(4K UHD)</option>
                                            <option value='4096x2160'>4096x2160(Full 4K)</option>
                                    </select>";
            
                            echo "Prezo: <input type='number' name='prezo'>";
                            echo "<input type='submit' name='buscar' value='buscar'>";
                        echo "</form>";
        }
        elseif($variable == 11 ){
            //FORMULARIO TAGS DE CASCOS
            echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";

            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
            $i=0;
            if($db){                       
                $cons='SELECT * FROM marca';
                $res = mysqli_query($db, $cons);
                    if($res){
                        echo"Marca: <select name='marca'>";
                                echo "<option value=''>---</option>";
                            while($marcas = mysqli_fetch_assoc($res)){                                    
                                echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                            }                               
                                echo"</select>";
                        
                    }else{
                        echo "<h1>Erro ao facer a consulta</h1>";
                    }                       
                
            }else{
                echo "<h1>Non se conecta a BD</h1>";
            }
    
            echo "Tipo de Cascos: <select name='conexion'>
                                <option value=''>---</option>
                                <option value='bluetooth'>Bluethoot</option>
                                <option value='jack'>Jack</option>
                                <option value='jack35'>Jack 3.5</option>
                                <option value='microusb'>Micro USB</option>
                                <option value='miniusb'>Mini USB</option>
                                <option value='usb'>USB</option>
                                <option value='usbc'>usb-c</option>
                        </select>";

                echo "Prezo: <input type='number' name='prezo'>";
                echo "<input type='submit' name='buscar' value='buscar'>";
            echo "</form>";
        }
        elseif($variable == 12 ){
            //FORMULARIO TAGS DE MICROFONOS
            echo "<form id='tags' method='post' action='generarProductos.php?prod=$variable'>";

            $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
            $i=0;
            if($db){                       
                $cons='SELECT * FROM marca';
                $res = mysqli_query($db, $cons);
                    if($res){
                        echo"Marca: <select name='marca'>";
                                echo "<option value=''>---</option>";
                            while($marcas = mysqli_fetch_assoc($res)){                                    
                                echo "<option value=".$marcas['id_marca'].">".$marcas['nome_marca']."</option>";
                            }                               
                                echo"</select>";
                        
                    }else{
                        echo "<h1>Erro ao facer a consulta</h1>";
                    }                       
                
            }else{
                echo "<h1>Non se conecta a BD</h1>";
            }
    
            echo "Tipo de Micrófono: <select name='micro'>
                                <option value=''>---</option>
                                <option value='condensador'>Condensador</option>
                                <option value='inalambrico'>Inalámbrico</option>
                                <option value='dinamico'>Dinámico</option>
                        </select>";

                echo "Prezo: <input type='number' name='prezo'>";
                echo "<input type='submit' name='buscar' value='buscar'>";
            echo "</form>";
        }

if(!empty($_POST)){
    $variable = $_GET["prod"];

    //FLITROS DE PROCESADORES
    if(isset($_POST['nucleos']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['nucleos'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['nucleos']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['nucleos']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable  AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Nucleos:".$_POST['nucleos']."%' ";
        }elseif(empty($_POST['nucleos'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }

    //FILTROS DE DISCOS DUROS
    if(isset($_POST['capacidad']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['capacidad'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['capacidad']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['capacidad']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable  AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Capacidad:".$_POST['capacidad']."%' ";
        }elseif(empty($_POST['capacidad'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }
 
    //FLITROS PLACAS BASE
     if(isset($_POST['chipset']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['chipset'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['chipset']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['chipset']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable  AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Chipset:".$_POST['chipset']."%' ";
        }elseif(empty($_POST['chipset'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }

        //FLITROS TARJETAS GRAFICAS
     if(isset($_POST['tipo']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['tipo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['tipo']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['tipo']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable  AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."'AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['tipo']."%' ";
        }elseif(empty($_POST['tipo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }

    //FLITROS RATONES
    if(isset($_POST['raton']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['raton'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['raton']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['raton']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['raton']."%' ";
        }elseif(empty($_POST['raton'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }

    //FLITROS TECLADOS
    if(isset($_POST['switches']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['switches'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['switches']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['switches']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['switches']."%' ";
        }elseif(empty($_POST['switches'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }

    //FLITROS MONITORES
    if(isset($_POST['panel']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['panel'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['panel']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['panel']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Tipo:".$_POST['panel']."%' ";
        }elseif(empty($_POST['panel'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
        
    }
    //FLITROS DISIPACION
    if(isset($_POST['disipacion']) && isset($_POST['prezo']) && isset($_POST['marca'])){

        if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['disipacion'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }elseif(!empty($_POST['disipacion']) && !empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' order by prezo desc";
        }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
        }elseif(!empty($_POST['disipacion']) && !empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' ";
        }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' order by prezo desc ";
        }elseif(empty($_POST['marca'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' order by prezo desc ";
        }elseif(empty($_POST['prezo'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' AND id_marca = '".$_POST['marca']."'";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Disipacion:".$_POST['disipacion']."%' ";
        }elseif(empty($_POST['disipacion'])){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
            $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
        }
    }

//FLITROS CAJAS
        if(isset($_POST['caja']) && isset($_POST['prezo']) && isset($_POST['marca'])){

            if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['caja'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }elseif(!empty($_POST['caja']) && !empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Formato:".$_POST['caja']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' order by prezo desc";
            }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
            }elseif(!empty($_POST['caja']) && !empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%Formato:".$_POST['caja']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' ";
            }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' order by prezo desc ";
            }elseif(empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Formato:".$_POST['caja']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' order by prezo desc ";
            }elseif(empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Formato:".$_POST['caja']."%' ";
            }elseif(empty($_POST['caja'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }
        }

        //FLITROS TELEVISIONS
        if(isset($_POST['resolucion']) && isset($_POST['prezo']) && isset($_POST['marca'])){

            if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['resolucion'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }elseif(!empty($_POST['resolucion']) && !empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' order by prezo desc";
            }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
            }elseif(!empty($_POST['resolucion']) && !empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' ";
            }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' order by prezo desc ";
            }elseif(empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' order by prezo desc ";
            }elseif(empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%Resolucion:".$_POST['resolucion']."%' ";
            }elseif(empty($_POST['resolucion'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }
        }

        //FLITROS CASCOS
        if(isset($_POST['conexion']) && isset($_POST['prezo']) && isset($_POST['marca'])){

            if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['conexion'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }elseif(!empty($_POST['conexion']) && !empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' order by prezo desc";
            }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
            }elseif(!empty($_POST['conexion']) && !empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' ";
            }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' order by prezo desc ";
            }elseif(empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' order by prezo desc ";
            }elseif(empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%conexion:".$_POST['conexion']."%' ";
            }elseif(empty($_POST['conexion'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }
        }
    
        //FLITROS MICROFONOS
        if(isset($_POST['micro']) && isset($_POST['prezo']) && isset($_POST['marca'])){

            if(!empty($_POST['marca']) && !empty($_POST['prezo']) && !empty($_POST['micro'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }elseif(!empty($_POST['micro']) && !empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND  prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' order by prezo desc";
            }elseif(!empty($_POST['prezo']) && !empty($_POST['marca'])){   
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND id_marca = '".$_POST['marca']."' order by prezo desc ";
            }elseif(!empty($_POST['micro']) && !empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."'  AND caracteristicas LIKE '%micro:".$_POST['micro']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' ";
            }elseif(empty($_POST['marca']) && empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' order by prezo desc ";
            }elseif(empty($_POST['marca'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND prezo <='".$_POST['prezo']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' order by prezo desc ";
            }elseif(empty($_POST['prezo'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable AND caracteristicas LIKE '%micro:".$_POST['micro']."%' AND id_marca = '".$_POST['marca']."'";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND caracteristicas LIKE '%micro:".$_POST['micro']."%' ";
            }elseif(empty($_POST['micro'])){
                $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable  AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' ";
                $consulta= "SELECT * FROM productos WHERE id_articulo=$variable AND id_marca = '".$_POST['marca']."' AND prezo <='".$_POST['prezo']."' order by prezo desc ";
            }
        }




    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");

    //CONTAR NUMERO DE PRODUCTOS 
    if($db){
        $res2 = mysqli_query($db, $consulta2);
        $cantidad_prod = mysqli_fetch_row($res2);
            
        if(isset($_GET["paxina"])){
            if($_GET["paxina"] > 0){
                
                    $res = mysqli_query($db, $consulta);
                    if($res){
                        while($prod = mysqli_fetch_assoc($res)){
                            echo "<a href='generarArticulo.php?art=".$prod['id_prod']."'>";
                            echo "<article class='imagen'>";
                            echo "<h2 id='titulo_art'>"."<p>".$prod['titulo']."</p>"."</h2>";
                            echo "<img src=".$prod['imaxe'].">";
                            echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
                            echo "</article>";
                            echo "</a>";
                            $cont++;
                        }
                    }else{
                        echo "Erro na consulta";
                    }

                echo "
            <div id='botonnavegar'>
            <ul>";
                if(isset($_GET['paxina'])){

                    if($pax > 1){
                        
                        echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxant."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

                    }
                }
                if(($cont < $cantidad_prod[0]) || ($cont == 0)){
                    
                    echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
                }


            "</ul>";
        echo "</div>";

            }
        }else{
    
            $res = mysqli_query($db, $consulta);
            if($res){
                while($prod = mysqli_fetch_assoc($res)){
                    echo "<a href='generarArticulo.php?art=".$prod['id_prod']."'>";
                    echo "<article class='imagen'>";
                    echo "<h2 id='titulo_art'>"."<p>".$prod['titulo']."</p>"."</h2>";
                    echo "<img src=".$prod['imaxe'].">";
                    echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
                    echo "</article>";
                    echo "</a>";
                    $cont++;
                }
            }else{
                echo "Erro na consulta";
            }
            
        echo"<div id='botonnavegar'>
        <ul>";
            if(isset($_GET['paxina'])){

                if($pax >= 1){
                    
                    echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxant."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

                }
            }
            if(($cont < $cantidad_prod[0]) || ($cont == 0)){
                
                echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
            }


        "</ul>";
        echo "</div>";
    }
}
 //FINAL $post           
}else{

            $variable = $_GET["prod"];
        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
        //CONTAR NUMERO DE PRODUCTOS 
        if($db){
            $consulta2= "SELECT count(id_prod) FROM productos WHERE id_articulo=$variable";
            $res2 = mysqli_query($db, $consulta2);
            $cantidad_prod = mysqli_fetch_row($res2);
            mysqli_close($db);
        }
        
           
if(isset($_GET["paxina"])){
    if($_GET["paxina"] > 0){
        $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
        if($db){
            $consulta = "SELECT id_prod, titulo, imaxe, prezo FROM productos WHERE id_articulo=$variable LIMIT $x,6";
            $res = mysqli_query($db, $consulta);
            if($res){
                while($prod = mysqli_fetch_assoc($res)){
                    echo "<a href='generarArticulo.php?art=".$prod['id_prod']."'>";
                    echo "<article class='imagen'>";
                    echo "<h2 id='titulo_art'>"."<p>".$prod['titulo']."</p>"."</h2>";
                    echo "<img src=".$prod['imaxe'].">";
                    echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
                    echo "</article>";
                    echo "</a>";
                    $cont++;
                }
            }else{
                echo "Erro na consulta";
            }


        }else{
            echo "Mal conectado";
        }
        echo "
    <div id='botonnavegar'>
    <ul>";
        if(isset($_GET['paxina'])){

            if($pax > 1){
                
                echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxant."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

            }
        }
        if(($cont < $cantidad_prod[0]) || ($cont == 0)){
           
            echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
        }


    "</ul>";
echo "</div>";

    }
}else{

    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $consulta = "SELECT id_prod, titulo, imaxe, prezo FROM productos WHERE id_articulo=$variable LIMIT 0,6";
        $res = mysqli_query($db, $consulta);
        if($res){
            while($prod = mysqli_fetch_assoc($res)){
                echo "<a href='generarArticulo.php?art=".$prod['id_prod']."'>";
                echo "<article class='imagen'>";
                echo "<h2 id='titulo_art'>".$prod['titulo']."</h2>";
                echo "<img src=".$prod['imaxe'].">";
                echo "<p id='prezo'>".$prod['prezo']."$"."</p>";
                echo "</article>";
                echo "</a>";
                $cont++;
            }
            mysqli_close($db);
        }else{
            echo "Erro na consulta";
        }
        
    }
    echo"<div id='botonnavegar'>
    <ul>";
        if(isset($_GET['paxina'])){

            if($pax > 1){
                
                echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxant."'><img class='botonnav' src='../imaxes/esquerda.png'/></a></li>";

            }
        }
        if(($cont < $cantidad_prod[0]) || ($cont == 0)){
            
            echo "<li><a href='generarProductos.php?prod=$variable&paxina=".$paxsig."'><img class='botonnav' src='../imaxes/dereita.png'/></a></li>";
        }


    "</ul>";
    echo "</div>";
}

}     
    ?>       
    </body>
</html>