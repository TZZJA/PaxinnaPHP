<?php

function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}


$nome_marca = valida('nomemarca');


$nome_marcaOK= false;


if ($nome_marca == "") {
    print "  <h1>Non escribiu o nombre</h1>";
    print "\n";
}else {
    $nome_marcaOK = true;
}

if($nome_marcaOK){
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $insertar= "INSERT INTO marca(id_marca, nome_marca) VALUES(default, '".$nome_marca."')";
        $res = mysqli_query($db, $insertar);
        if($res){
            mysqli_close($db);
            echo "<h1>Marca Insertada!</h1>";
        }else{
            echo "<h1>Non se insertou!</h1>";
            mysqli_close($db);
        }

    }else {
        echo "<h1>mal conectado</h1>";
        mysqli_close($db);
    }
}

echo "<aside id='esquerda'>";
echo "</aside>";
echo "<section id='main'>"; 

?>