<?php
include 'header2.php';
function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}

$direccion = valida("direccion");
$tarjeta = valida("tarjeta");
$direccionOK = false;
$tarjetaOK = false;

echo "<aside id='esquerda'>";
echo "</aside>";

echo "<section id='main'>"; 


if ($direccion == "") {
    print "  <p class=\"aviso\">Non escribiu ben o a dirección</p>\n";
    print "\n";
}else {
    $direccionOK = true;
}

if ($tarjeta == "") {
    print "  <p class=\"aviso\">Non escribiu o numero da tarxeta</p>\n";
    print "\n";
}elseif(!preg_match("/^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9][0-9])[0-9]{12})$/", $tarjeta)){
    echo "Formato da tarxeta non compatible";
}else {
    $tarjetaOK = true;
}

if($direccionOK && $tarjetaOK){
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $insercion = "INSERT INTO pedidos(n_productos, prezo_total, fecha_pedido, id_usuario) values('".$_POST['total_prod']."', '".$_POST['precio']."', '".date('Y-m-d')."', '".$_SESSION['id_usuario']."' )";
        $ben_insert = mysqli_query($db, $insercion);
        if($ben_insert){
            $insercion2 = "SELECT max(id_compra) from pedidos";
            $ben_insert2 = mysqli_query($db,$insercion2);
            if($ben_insert2){
                $id_compra = mysqli_fetch_row($ben_insert2);
                $consulta = "SELECT id_prod FROM deseados WHERE id_usuario='".$_SESSION['id_usuario']."'";
                $res = mysqli_query($db, $consulta);
                while($id_producto = mysqli_fetch_assoc($res)){
                    $consulta3 = "SELECT cantidad from deseados where id_prod = '".$id_producto['id_prod']."' AND id_usuario='".$_SESSION['id_usuario']."'";
                    $ben_insert3 = mysqli_query($db, $consulta3);
                    if($ben_insert3){
                        $cantidad = mysqli_fetch_assoc($ben_insert3);
                        $consulta4 = "INSERT INTO pedidos_productos(id_compra, id_prod, unidades) VALUES('".$id_compra[0]."', '".$id_producto['id_prod']."', '".$cantidad['cantidad']."')";
                        $ben_insert4 = mysqli_query($db, $consulta4);
                    }
                }
            }

        }
        
    }else{
        echo "Non conectado";
    }
}
echo "</section>";
echo "<aside id='dereita'>";
echo "</aside>";
include 'footer.php';
?>