<?php

function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}

$nomeUsuario    = valida("nomuser");
$apelidoUsuario    = valida("apeluser");
$tlfuser    = valida("telefono");
$emailUser  = valida("email");
$passUser   = valida("pass");
$confpassUser   = valida("conf_pass");
$tipoUser   = valida("select");


$nomeUsuarioOK  = false;
$apelidoUsuarioOK   = false;
$tlfuserOK    = false;
$emailUserOK    = false;
$passUserOK = false;
$confpassUserOK = false;
$tipoUserOK = false;
echo "<aside id='esquerda'>";
echo "</aside>";

echo "<section id='main'>"; 

if ($nomeUsuario == "") {
    print "  <h1>Non escribiu ben o nome do usuario</h1>";
    print "\n";
}elseif(!preg_match("/^([\w]|\s)*$/", $nomeUsuario)){
    echo "<h1>Nome de usuario mal formado</h1>";
}else {
    $nomeUsuarioOK = true;
}

if ($apelidoUsuario == "") {
    print "  <h1>Non escribiu ben o apelido do Articulo</h1>";
    print "\n";
}elseif(!preg_match("/^([\w]|\s)*$/", $apelidoUsuario)){
    echo "<h1>Apelido de articulo formando incorrectamente</h1>";
}else {
    $apelidoUsuarioOK = true;
}

if ($tlfuser == "") {
    print "  <h1>Non escribiu ben o telefono</h1>";
    print "\n";
}elseif(!preg_match("/\d{9}/", $tlfuser)){
    echo "telefono mal formado";
}else {
    $tlfuserOK = true;
}

if ($emailUser == "") {
    print "  <h1>Non escribiu o email</h1>";
    print "\n";
}elseif(!preg_match("/^\w*[@]\w*.\w*$/", $emailUser)){
    echo "<h1>Email mal formado</h1>";
}else {
    $emailUserOK = true;
}

if (($passUser == "") && ($confpassUser == "")) {
    print "  <h1>O contrasinal está vacio</h1>";
    print "\n";
}elseif(strcmp($passUser, $confpassUser)){
    echo "<h1>O email non coincide</h1>";
}else {
    $passUserOK = true;
    $confpassUserOK = true;
}

if ($tipoUser == "") {
    print "  <h1>Tipo de usuario non especificado</h1>";
    print "\n";
}elseif(($tipoUser != "admin") && ($tipoUser != "normal")){
    echo "<h1>Tipo de usuario no valido</h1>";
}else {
    $tipoUserOK = true;
}

if ($nomeUsuarioOK && $apelidoUsuarioOK && $tlfuserOK && $emailUserOK && $passUserOK && $tipoUserOK) {
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $insercion = "INSERT INTO usuarios(id_usuario, nombre, apellido, telefono, email, tipo, contrasenha, imaxe) VALUES (default, '".$nomeUsuario."', '".$apelidoUsuario."', '".$tlfuser."', '".$emailUser."', '".$tipoUser."', '".$passUser."', null)";
        $res = mysqli_query($db, $insercion);
        if($res){
            mysqli_close($db);
            echo "<h1>Registrado!</h1>";
        }else{
            echo "<h1>Email Repetido!</h1>";
            mysqli_close($db);
        }

    }else {
        echo "<h1>mal conectado</h1>";
        mysqli_close($db);
    }
}
echo "</section>";

?>
