<?php
session_start();
function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}

$nomeArticulo       = valida("nom_art");
$tipoArticulo   = valida("tipo");
$caracArticulo      = valida("carc_art");
$descripcion      = valida("descrip_art");
$prezoProd      = valida("prezo");
$marca  =valida("marca");

$nomeArticuloOK     = false;
$tipoArticuloOK = false;
$caracArticuloOK     = false;
$descripcionOK     = false;
$prezoProdOK     = false;
$marcaOK  = false;

$random = rand(1,100) + rand(1,650) + rand(1,200);


if ($nomeArticulo == "") {
    print "  <h1>Non escribiu ben o nome do Articulo</h1>";
    print "";
}elseif(!preg_match("/^([\w](.)*|\s)*$/", $nomeArticulo)){
    echo "<h1>Nome de articulo formando incorrectamente<h1>";
}else {
    $nomeArticuloOK = true;
}
$db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $consulta = "SELECT id_articulo from tipo_articulo where id_articulo=$tipoArticulo";
        $res = mysqli_query($db, $consulta);
        if($res){
            $idart = mysqli_fetch_assoc($res);
            
                if($tipoArticulo == $idart['id_articulo']){
                    $tipoArticuloOK = true;
                }else{
                    echo "<h1>Tipo de articulo Incorrecto</h1>";
                }
            }
            mysqli_close($db);
        
    }else{
        mysqli_close($db);
    }

    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $consulta = "SELECT id_marca from marca where id_marca=$marca";
        $res = mysqli_query($db, $consulta);
        if($res){
            $idmarca = mysqli_fetch_assoc($res);
            
                if($marca == $idmarca['id_marca']){
                    $marcaOK = true;
                }else{
                    echo "<h1>Marca Incorrecta</h1>";
                }
            }else{
                echo "<h1>Consulta mal feita</h1>";
            }
            mysqli_close($db);
        
    }else{
        mysqli_close($db);
    }




    
if ($caracArticulo == "") {
    print "  <h1>Caracteristica no valida</h1>";
    print "";
} elseif (!preg_match("/(\w*\:\w*;)+/", $caracArticulo)) {
    print "  <h1>Mal escritas as caracteristicas.</h1>";
    print "";
} else {
    $caracArticuloOK = true;
}

if ($descripcion == "") {
    print "  <h1>Non escribiu a descripcion.</h1>";
    print "";
} else {
    $descripcionOK = true;
}

if ($prezoProd == "") {
    print "  <h1>O prezo esta vacío</h1>";
    print "";
} elseif(!is_numeric($prezoProd)) {
    echo "<h1>O valor non é numerico</h1>";
}else{
    $prezoProdOK = true;
}

if (isset($_FILES['img_prod'])) {
    if ($_FILES['img_prod']['error'] === UPLOAD_ERR_OK) {
        $ruta_local = $_FILES['img_prod']['tmp_name'];
        $nome_imaxe = $_FILES['img_prod']['name'];
        $tamanho_foto = $_FILES['img_prod']['size'];
        $tipo_foto = $_FILES['img_prod']['type'];
        $archNomCmps = explode(".", $nome_imaxe);
        $extension_imaxe = strtolower(end($archNomCmps));
        $extensions_validas = array('jpg', 'png', 'jpeg');
        if (in_array($extension_imaxe, $extensions_validas)) {
            $subida = '../imaxesproductos/';
            $destino = $subida.$random.".".$extension_imaxe;
            if(move_uploaded_file ($ruta_local, $destino)) {
                $rutaimagen = $destino;
                $imagenOK = TRUE;
            } else {
                print "<h1>Erro ao subir a imaxe</h1>";
                print "";
            }
        } else {
            print "<h1>Imaxen incorrecta, só tipo png ou jpg</h1>";
            print "";
        }
    } elseif ($_FILES['imagen']['error'] === 4) {
        echo "<h1>No has seleccionado una imagen para el producto</h1>";
    } else {
        print "<h1>Error na subida</h1>";
    }
}


if ($nomeArticuloOK && $tipoArticuloOK && $caracArticuloOK && $descripcionOK && $prezoProdOK && $imagenOK && $marcaOK) {
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");

    if($db){
        $insercion = "INSERT INTO productos(id_prod, titulo, caracteristicas, descripcion, prezo, imaxe, id_admin, id_marca, id_articulo) VALUES (default, '".$nomeArticulo."', '".$caracArticulo."', '".$descripcion."', ".$prezoProd.", '".$rutaimagen."', ".$_SESSION['id_usuario'].", ".$marca.", ".$tipoArticulo.") ";
        $res = mysqli_query($db, $insercion);
        if($res){
            echo "Ben Inserido";
        }else{
            echo "Mal Inserido";
            echo $insercion;
        }

    }else{
        echo"Error ao conectarme a BD";
    }
}else{
    echo"<h1>Campos mal postos</h1>";
    echo $tipoArticulo;
}

?>

