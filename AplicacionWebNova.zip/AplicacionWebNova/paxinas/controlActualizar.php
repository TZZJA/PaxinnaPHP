<?php
include'header2.php';
function valida($var)
{
    if (!isset($_REQUEST[$var])) {
        $tmp = "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}

$nomeUsuario    = valida("nome");
$apelidoUsuario    = valida("apelido1");
$tlfuser    = valida("telefono");
$emailUser  = valida("email");
$passUser   = valida("contrasinal1");
$confpassUser   = valida("contrasinal2");

$nomeUsuarioOK  = false;
$apelidoUsuarioOK   = false;
$tlfuserOK    = false;
$emailUserOK    = false;
$passUserOK = false;
$confpassUserOK = false;
$tipoUserOK = false;

echo "<aside id='esquerda'>";
echo "</aside>";

echo "<section id='main'>"; 

if ($nomeUsuario == "") {
    print "  <h1>Non escribiu ben o nome</h1>";
}elseif(!preg_match("/^([\w]|\s)*$/", $nomeUsuario)){
    echo "Nome de usuario mal formado";
}else {
    $nomeUsuarioOK = true;
}

if ($apelidoUsuario == "") {
    print "  <h1>Non escribiu ben o apelido do Articulo</h1>";
}elseif(!preg_match("/^([\w]|\s)*$/", $apelidoUsuario)){
    echo "Apelido de articulo formando incorrectamente";
}else {
    $apelidoUsuarioOK = true;
}

if ($tlfuser == "") {
    print "  <h1>Non escribiu ben o telefono</h1>";
}elseif(!preg_match("/\d{9}/", $tlfuser)){
    echo "telefono mal formado";
}else {
    $tlfuserOK = true;
}

if ($emailUser == "") {
    print "  <h1>Non escribiu o email</h1>";
}elseif(!preg_match("/^\w*[@]\w*.\w*$/", $emailUser)){
    echo "Email mal formado";
}else {
    $emailUserOK = true;
}

if (($passUser == "") && ($confpassUser == "")) {
    print "  <h1>O contrasinal está vacio</h1>";
}elseif(strcmp($passUser, $confpassUser)){
    echo "O email non coincide";
}else {
    $passUserOK = true;
    $confpassUserOK = true;
}


if (isset($_FILES['img_perfil'])) {
    if ($_FILES['img_perfil']['error'] === UPLOAD_ERR_OK) {
        $ruta_local = $_FILES['img_perfil']['tmp_name'];
        $nome_imaxe = $_FILES['img_perfil']['name'];
        $tamanho_foto = $_FILES['img_perfil']['size'];
        $tipo_foto = $_FILES['img_perfil']['type'];
        $archNomCmps = explode(".", $nome_imaxe);
        $extension_imaxe = strtolower(end($archNomCmps));
        $extensions_validas = array('jpg', 'png', 'jpeg');
        if (in_array($extension_imaxe, $extensions_validas)) {
            $subida = '../imaxesperfil/';
            $destino = $subida.$_SESSION["nombre"].".".$extension_imaxe;
            print_r($ruta_local);
            echo "<br/>";
            print_r($destino);
            if(move_uploaded_file ($ruta_local, $destino)) {
                $rutaimagen = $destino;
                $imagenOK = TRUE;
            } else {
                print "<h1>Erro ao subir a imaxe</h1>";
            }
        } else {
            print "<h1>Imaxen incorrecta, só tipo png ou jpg</h1>";
        }
    } elseif ($_FILES['img_perfil']['error'] === 4) {
        $imagenOK = true;
        $rutaimagen = '../imaxesperfil/default.png';
    } else {
        print "<h1>Error na subida</h1>";
    }
}


if ($nomeUsuarioOK && $apelidoUsuarioOK && $tlfuserOK && $emailUserOK && $passUserOK && $imagenOK) {
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");

    if($db){
        $insercion = $insercion = "UPDATE usuarios SET nombre='".$nomeUsuario."' , apellido='".$apelidoUsuario."' , telefono='".$tlfuser."', email='".$emailUser."', contrasenha='".$passUser."', imaxe= '".$rutaimagen."' WHERE id_usuario=".$_SESSION['id_usuario']."";
        $res = mysqli_query($db, $insercion);
        if($res){
            echo "<h1>Ben actualizado<br/>Se cambiaches a imaxe tes que volver a loguearte</h1>";
        }else{
            echo "Mal actualizado";
            echo $insercion;
        }

    }else{
        echo"Error ao conectarme a BD";
    }
}else{
    echo "<h1>MAL</h1>";
}

echo "</section>";
echo "<aside id='dereita'>";
echo "</aside>";
include'footer.php';
?>