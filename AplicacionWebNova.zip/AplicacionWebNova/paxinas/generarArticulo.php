<html>
    <head>
            <link href='../css/css.css' rel='stylesheet' type='text/css'/>
    </head>
    <body> 
<?php
    include '../datos/datos.php';
    session_start();

    $idArtigo=$_GET["art"];
    $delimitador=";";

    echo "
        <form method='post' action='generarArticulo.php'>
        </form>
    ";
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
        if($db){
            $consulta = "SELECT id_prod, titulo, caracteristicas, descripcion, prezo, imaxe from productos where id_prod=$idArtigo";
            $res = mysqli_query($db, $consulta);
            if($res){


                while ($artGen = mysqli_fetch_assoc($res)) {
                    $cadena_caracter = $artGen['caracteristicas'];
                    $caract = explode($delimitador, $cadena_caracter);
                    $cont_caract= count($caract);
                
                            echo    "<section id='art'>
                                        <article id='prod'>
                                                <div class='container'>
                                                    <ul class='slider'>
                                                        <li id='slide1'>";
                                                        echo"<img src=".$artGen['imaxe'].">";
                                echo "                   </li>
                                                    </ul>
                                                </div>
                                                <div id='info'>
                                                    <h2>".$artGen['titulo']."</h2>";
                                                        for ($j=0; $j<$cont_caract; $j++){
                                                        echo "<p>".$caract[$j]."</p>";
                                                        }
                                                echo "<p><b>".$artGen["descripcion"]."</b></p>";
                                                echo "<h1 id='prezo'>".$artGen["prezo"]."$"."</h1>";
                                echo            "</div>";
                                                if(!empty($_SESSION)){
                                                    echo "  <div id='botons'>
                                                                <div>
                                                                    <form method='post' action='controldeseo.php' target='_parent'>
                                                                        <input id='boton_deseo' type='submit' name='deseo' value='Añadir a deseados'/>
                                                                        <input type='hidden' name='oculto' value='$artGen[id_prod]'/>
                                                                    </form>
                                                                </div>
                                                                <div>
                                                                    <form method='post' action='controlcarro.php' target='_parent'>
                                                                        <input id='boton_comprar' type='submit' name='comprar' value='Comprar'/>
                                                                        <input type='hidden' name='oculto' value='$artGen[id_prod]'/>
                                                                    </form>
                                                                </div>
                                                            </div>";
                                                } else{
                                                    echo "<div id='botons'>
                                                            <h3>Rexistrate ou logeate para comprar!</h3>
                                                          </div>"; 
                                                }
                                echo"   </article>
                                    </section>";
                }

            }else{
                echo "Mal seleccionado";
            }
            
        }else{
            echo "Non se conectou";
        }
    

?>
    </body>
</html>
