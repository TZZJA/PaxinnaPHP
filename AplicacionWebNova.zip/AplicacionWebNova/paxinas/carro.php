<html>
<?php
include'header2.php';
if(isset($_POST["mas_x"])){
    $db =  mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $actu = "UPDATE deseados SET cantidad = cantidad+1 WHERE id_usuario='".$_SESSION['id_usuario']."' AND id_prod='".$_POST['id_producto']."'";
        mysqli_query($db, $actu); 
    }
    mysqli_close($db);

}elseif(isset($_POST["menos_x"])){
    $db =  mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $actu = "UPDATE deseados SET cantidad = cantidad-1 WHERE id_usuario='".$_SESSION['id_usuario']."' AND id_prod='".$_POST['id_producto']."'";
        mysqli_query($db, $actu);
    }
    mysqli_close($db);
}

if(isset($_POST["eliminar_x"])){

    $db =  mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if($db){
        $borrar = "DELETE from deseados WHERE id_usuario='".$_SESSION['id_usuario']."' AND id_prod='".$_POST['id_producto']."'";
        mysqli_query($db, $borrar);
        mysqli_close($db);
    }
}

?>

<aside id="esquerda">
    <?php
    //print_r($_POST);
    //echo $_POST['menos'];
    ?>
</aside>

<?php
    $db = mysqli_connect("localhost", "root", "", "tenda_hw_boa");
    if(isset($_GET["usuario"])){
        if($db){
            $consulta = "SELECT id_prod FROM deseados WHERE id_usuario='".$_SESSION['id_usuario']."'";
            $res = mysqli_query($db, $consulta);
            if($res){
                echo "
                        <section id='main'>
                            <h1>Carrito del usuario</h1>
                            <div id='carrito'>";
                                while ($parametrosArticulo = mysqli_fetch_assoc($res)) {
                                    $consulta2 = "SELECT id_prod, titulo, prezo, imaxe FROM productos where id_prod='".$parametrosArticulo['id_prod']."'";
                                    $res2 = mysqli_query($db, $consulta2);
                                    $comprar = mysqli_fetch_assoc($res2);
                                    echo"
                                    <div class='carro'>
                                        <div class='art'>
                                            <img id='imgcarro' src='".$comprar['imaxe']."' />
                                        </div>
                                        <div class='art'>".$comprar['titulo']."</div>
                                        <div class='art'>";
                                        $cantidad = "SELECT cantidad FROM deseados WHERE id_prod = '".$parametrosArticulo['id_prod']."' AND id_usuario = '".$_SESSION['id_usuario']."'";
                                        $res3 = mysqli_query($db, $cantidad);
                                        $cant = mysqli_fetch_assoc($res3); 
                                echo"       <form method='post' action='carro.php?usuario=".$_SESSION['id_usuario']."'>
                                                <p>Cantidade: ".$cant['cantidad']."</p>
                                                <input id='boton_cont1' type='image' src='../imaxes/mas.png' name='mas'/>";

                                                if($cant['cantidad'] > 1){
                                                    //multiplicar a cantidade polo precio
                                                    echo" <input id='boton_cont2' type='image' src='../imaxes/menos.png' name='menos'/>";
                                                }

                               echo"           <input type='hidden' name='id_producto' value='".$parametrosArticulo['id_prod']."'/>
                                                </div>
                                                <div class='art'>".$comprar['prezo']."</div>
                                                <div class='art'>
                                                        <input type='image' id='imgpapel' src='../imaxes/papelera.png' name='eliminar' />                                           
                                                </div>
                                            </form>
                                    </div>";

                                }
                                $contar = "SELECT count(id_usuario) from deseados where id_usuario = '".$_SESSION['id_usuario']."' ";
                                $res4 = mysqli_query($db, $contar);
                                $contar_prod = mysqli_fetch_row($res4);
                                if($contar_prod[0] > 0){
                                    echo "<form method='post' action='pago.php?usuario=".$_SESSION['id_usuario']."'>
                                                <input id='pagar' type='submit' name='comprar' value='Comprar'/>
                                          </form>";
                                }else{
                                    echo "<center>";
                                    echo "El carrito está vacío";
                                    echo "</center>";
                                }
                                        

                                
                                

                echo "      </div>
                        </section>";
            }
        }else{
            echo "Mal conectado";
        }
    }elseif(isset($_SESSION["tipo"])) {
        if($_SESSION["tipo"] == "admin"){
            echo "<section id='main'>
                    <h1>Ti non podes comprar</h1>";

            echo "</section>";
        }
    }else{
        echo " <section id='main'>
                <h1>Logeate para ver tu carrito</h1>";  
        echo " </section>";

    }
?>
    <aside id='dereita'>                
    </aside>

<?php
  include 'footer.php';
?>

  </body>
</html>