<?php
//$enlace_actual = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
echo "
<div id='botonnavegar'>
    <ul>";  
    //print_r($_GET["paxina"]);
    if(isset($_GET['paxina'])){
      //$enlace_actual="";
      if( $pax > 1){
          echo "<li><a href='inicio.php?paxina=".$paxant."'><img class='botonnav' src='imaxes/esquerda.png'/></a></li>";
          
      }
    }
    if($cont < $cantidad_prod[0]){
        echo "<li><a name href='inicio.php?paxina=".$paxsig."'><img class='botonnav' src='imaxes/dereita.png'/></a></li>";
       
    }

    echo "</ul>";
echo "</div>";

?>