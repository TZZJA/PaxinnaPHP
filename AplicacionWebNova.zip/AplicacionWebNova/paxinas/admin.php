<html>
<?php
include'header2.php';
include'../datos/datos.php';
?>

<aside id="esquerda">

</aside>

    <section id="main">
      <h1>Panel de Administración</h1>
        <article id="prod">
          <div id="frame">
            <ul >
              <li><a href="insert_users.php" target="iframe_a">Insertar usuarios</a></li>
              <li><a href="del_users.php" target="iframe_a">Borrar usuario</a></li>
              <li><a href="insert_prod.php" target="iframe_a">Insertar producto</a></li>
              <li><a href="del_prod.php" target="iframe_a">Borrar producto</a></li>
              <li><a href="insert_marca.php" target="iframe_a">Insertar marcas</a></li>
              <li><a href="devol_prod.php" target="iframe_a">Ver devoluciones</a></li>
            </ul>
          </div>
            <iframe src="" name="iframe_a" height="410px" width="100%" title="xd" frameborder="0"></iframe>
        </article>
    </section>

    <aside id="dereita">

    </aside>



<?php
  include 'footer.php';
?>

  </body>
</html>
