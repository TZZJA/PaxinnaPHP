<?php
    $productos = array(
        array("id_prod" => 1, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "Nucleos: 4;Hilos: 8; Cache: 32", "descripcion" => "Procesador de 4 nucleos y 8 hilos", "prezo" => 200, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 2, "titulo" => "DISCO TOSHIBA 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 3, "titulo" => "DISCO KINGSTON 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 4, "titulo" => "DISCO SEAGATE 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 5, "titulo" => "DISCO WD 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 6, "titulo" => "DISCO CHINO 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 7, "titulo" => "DISCO JAPONES 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 8, "titulo" => "DISCO TOSHIBA 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 9, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 2 nucleos y 4 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin"=> 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 10, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 2 nucleos y 2 hilos", "prezo" => 130, "imaxe" => "imaxes/procesador.png", "id_admin"=> 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 11, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 8 nucleos y 16 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin" =>1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 12, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 4 nucleos y 8 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin"=> 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 13, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 4 nucleos y 8 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin"=> 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 14, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 4 nucleos y 8 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin"=> 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 15, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 6 nucleos y 12 hilos", "prezo" => 200, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 16, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 4 nucleos y 8 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 17, "titulo" => "PROCESADOR RYZEN MODELO XXXX", "caracteristicas" => "nucleos", "descripcion" => "Procesador de 4 nucleos y 8 hilos", "prezo" => 125, "imaxe" => "imaxes/procesador.png", "id_admin"=> 1, "id_marca" => 1, "id_articulo" => 1),
        array("id_prod" => 18, "titulo" => "DISCO TOSHIBA 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 19, "titulo" => "DISCO TOSHIBA 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 2),
        array("id_prod" => 20, "titulo" => "DISCO TOSHIBA 1TB", "caracteristicas" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "descripcion" => "Disco duro de 1TB", "prezo" => 40, "imaxe" => "imaxes/procesador.png", "id_admin" => 1, "id_marca" => 1, "id_articulo" => 3)
        
    );

    $pedidos = array (
        array("id_compra" => 1, "n_productos" => 1, "fecha_compra" => 2020-12-12, "prezo_total" => 200, "IVA" => 21, "fecha_devolucion" => null, "fecha_pedido" => 2020-12-12, "id_usuario" => 1),
        array("id_compra" => 2, "n_productos" => 1, "fecha_compra" => 2020-12-12, "prezo_total" => 200, "IVA" => 21, "fecha_devolucion" => null, "fecha_pedido" => 2020-12-15, "id_usuario" => 2),
        array("id_compra" => 3, "n_productos" => 4, "fecha_compra" => 2020-12-15, "prezo_total" => 200, "IVA" => 21, "fecha_devolucion" => null, "fecha_pedido" => 2020-12-19, "id_usuario" => 1)
    );
    
    $marca = array (
        array("id_marca" => 1, "nome_marca" => "Asus"),
        array("id_marca" => 2, "nome_marca" => "MSI"),
        array("id_marca" => 3, "nome_marca" => "Gigabyte"),
        array("id_marca" => 4, "nome_marca" => "Corsair"),
        array("id_marca" => 5, "nome_marca" => "Razer"),
        array("id_marca" => 6, "nome_marca" => "Acer"),
        array("id_marca" => 7, "nome_marca" => "BenQ")
    );
    
     $tipo_articulo = array (
         array("id_articulo" => 1, "nome_articulo" => "procesador"),
         array("id_articulo" => 2, "nome_articulo" => "disco_duro"),
         array("id_articulo" => 3, "nome_articulo" => "placa"),
         array("id_articulo" => 4, "nome_articulo" => "tele"),
         array("id_articulo" => 5, "nome_articulo" => "teclados"),
         array("id_articulo" => 6, "nome_articulo" => "ratones"),
         array("id_articulo" => 7, "nome_articulo" => "grafica"),
         array("id_articulo" => 8, "nome_articulo" => "disipacion"),
         array("id_articulo" => 9, "nome_articulo" => "cascos"),
         array("id_articulo" => 10, "nome_articulo" => "monitor"),
         array("id_articulo" => 11, "nome_articulo" => "caja"),
         array("id_articulo" => 12, "nome_articulo" => "micro"),
     );


    $administrador = array (
        array("id_admin" => 1, "nombre" => "Juan", "apellidos" => "Perez", "telefono" => "712321232", "email" => "juan@gmail.com", "contrasenha" => "abc", "fecha_nacimiento" => 2020-12-01),
        array("id_admin" => 2, "nombre" => "Lucas", "apellidos" => "Mendez", "telefono" => "67123631921", "email" => "lucas@gmail.com", "contrasenha" => "abc123", "fecha_nacimiento" => 1999-12-01),
        array("id_admin" => 3, "nombre" => "Roi", "apellidos" => "Rodiño", "telefono" => "561234309", "email" => "roi@gmail.com", "contrasenha" => "12365221231", "fecha_nacimiento" => 1998-03-01)
    );

    $usuario_normal = array(
        array("id_usuario" => 2, "imaxe" => "imxperfil/perfilmanu.png", "nombre" => "Manuel", "apellido1" => "Aguado", "apellido2" => "Perez", "telefono" => "865129647", "email" => "manuel@gmail.com", "contrasenha" => "123", "fecha_nacimiento" => 2002-04-07),
        array("id_usuario" => 1, "imaxe" => "imxperfil/perfilpedro.png","nombre" => "Pedro", "apellido1" => "Garcia", "apellido2" => "Lopez", "telefono" => "875412096", "email" => "pedro@gmail.com", "contrasenha" => "98351231", "fecha_nacimiento" => 2006-07-13),
        array("id_usuario" => 2, "imaxe" => "imxperfil/perfiljesus.png", "nombre" => "Jesus", "apellido1" => "Aguado", "apellido2" => "Mendez", "telefono" => "865129647", "email" => "jesus@gmail.com", "contrasenha" => "843125534", "fecha_nacimiento" => 2002-04-07)
    );
    
    $pedidos_productos = array(
        array("id_compra"=> 1, "id_prod" => 1, "n_productos" => 1, "fecha_compra" => 2019-12-01, "prezo_total" => 200, "IVA" => 21, "caracteristicas" => null, "descripcion" => "Rpm: 7200;Capacidad: 1Tb; Cache: 16", "prezo"  => 200, "imaxe" => "imaxes/procesador.png")
    );
?>